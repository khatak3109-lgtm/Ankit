import { boolean, integer, jsonb, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

type FeatureItem = { title: string; detail: string };

export const apps = pgTable("apps", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  tagline: varchar("tagline", { length: 220 }).notNull(),
  description: text("description").notNull(),
  story: text("story").notNull(),
  audience: varchar("audience", { length: 280 }).notNull(),
  highlight: varchar("highlight", { length: 280 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("live"),
  version: varchar("version", { length: 40 }).notNull().default("1.0.0"),
  platforms: jsonb("platforms").$type<string[]>().notNull(),
  features: jsonb("features").$type<FeatureItem[]>().notNull(),
  accent: varchar("accent", { length: 20 }).notNull().default("#ff8a2a"),
  iconFile: text("icon_file"),
  coverFile: text("cover_file"),
  coverUrl: text("cover_url"),
  bundleFile: text("bundle_file"),
  bundleName: text("bundle_name"),
  websiteUrl: text("website_url"),
  featured: boolean("featured").notNull().default(false),
  sample: boolean("sample").notNull().default(false),
  downloads: integer("downloads").notNull().default(0),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 180 }).notNull(),
  topic: varchar("topic", { length: 80 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value").notNull(),
});
