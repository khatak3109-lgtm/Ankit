export const craftFeatures = [
  {
    key: "orbit",
    wide: true,
    en: {
      title: "Orbit publish",
      detail: "Save an app as live and it takes a glowing seat in the 3D sky. No second tool, no hidden listing step. The orbit is the catalog.",
    },
    hi: {
      title: "Orbit publish",
      detail: "App ko live save karte hi woh 3D aasman mein ek roshni ban jaati hai. Alag listing tool nahi. Orbit hi catalog hai.",
    },
  },
  {
    key: "explain",
    wide: false,
    en: {
      title: "Explain layer",
      detail: "Every app carries a story, an audience, one sharp difference, and a feature list. People should understand it before they tap install.",
    },
    hi: {
      title: "Explain layer",
      detail: "Har app ke saath kahani, audience, ek alag baat, aur features hain. Install se pehle log samajh jaayein yeh kis kaam ki hai.",
    },
  },
  {
    key: "file",
    wide: false,
    en: {
      title: "File or link",
      detail: "Upload an APK, ZIP, IPA, PDF, or DMG. If the build is large, paste a website or store link instead. Both can sit on the same page.",
    },
    hi: {
      title: "File ya link",
      detail: "APK, ZIP, IPA, PDF, ya DMG chadhhao. Badi file ho to website ya store ka link laga do. Dono ek hi page par reh sakte hain.",
    },
  },
  {
    key: "logo",
    wide: false,
    en: {
      title: "Your own mark",
      detail: "The opening emblem is a placeholder. Drop your logo in the studio and it replaces the mark across the site — nav, about, and icon slot.",
    },
    hi: {
      title: "Apna logo",
      detail: "Jo emblem ab dikh raha hai, woh shuruaat hai. Studio mein apna logo daalo — nav, about, aur mark sab jagah wahi aa jayega.",
    },
  },
  {
    key: "inbox",
    wide: false,
    en: {
      title: "Signal inbox",
      detail: "Visitors write from the page. Messages land in the studio, not in a forgotten form. Read them, reply from your own mail, clear the ones you are done with.",
    },
    hi: {
      title: "Signal inbox",
      detail: "Log page se likhte hain. Sandesh studio mein aate hain, kisi bhooli hui form mein nahi. Padho, apne mail se jawab do, jo ho gaya use hata do.",
    },
  },
  {
    key: "pulse",
    wide: false,
    en: {
      title: "Pulse",
      detail: "Each app counts looks and downloads. Small numbers, honest numbers — so you can see what people actually open.",
    },
    hi: {
      title: "Pulse",
      detail: "Har app dekhe jaane aur download hone ki ginti rakhti hai. Chhote, sachche numbers — taaki pata chale log kya khol rahe hain.",
    },
  },
  {
    key: "tongue",
    wide: false,
    en: {
      title: "Hindi and English",
      detail: "The shell speaks both. App words stay in the language you write them. Switch the chrome without rewriting your catalog.",
    },
    hi: {
      title: "Hindi aur English",
      detail: "Site ka frame dono bhasha bolta hai. App ke alfaaz usi bhasha mein rehte hain jis mein tum likho. Catalog dobara likhne ki zarurat nahi.",
    },
  },
  {
    key: "name",
    wide: false,
    en: {
      title: "A name Google can read",
      detail: "Titles, descriptions, a sitemap, and structured data all say the same thing: Ankit Hai. When the domain is yours, Search Console can pick up the signal.",
    },
    hi: {
      title: "Naam jo Google padh sake",
      detail: "Title, description, sitemap, aur structured data sab ek hi baat kehte hain: Ankit Hai. Domain lagte hi Search Console is signal ko utha sakta hai.",
    },
  },
] as const;

export const steps = [
  {
    n: "01",
    en: { title: "Studio kholo", detail: "The desk is at /studio. That is the only door that changes the sky." },
    hi: { title: "Studio kholo", detail: "Desk /studio par hai. Aasman sirf isi darwaze se badalta hai." },
  },
  {
    n: "02",
    en: { title: "Creator key", detail: "The opening key is ankit-hai. Change it after you enter, so the desk stays yours." },
    hi: { title: "Creator key", detail: "Shuruaati key ankit-hai hai. Andar aake badal dena, taaki desk sirf tumhara rahe." },
  },
  {
    n: "03",
    en: { title: "App samjhao", detail: "Name, who it is for, the one difference, and the features. Understanding comes before install." },
    hi: { title: "App samjhao", detail: "Naam, kiske liye hai, ek alag baat, aur features. Install se pehle samajh aana chahiye." },
  },
  {
    n: "04",
    en: { title: "File ya link", detail: "Add a cover, then an APK, ZIP, or a link. Live, beta, or soon — you choose the lane." },
    hi: { title: "File ya link", detail: "Cover lagao, phir APK, ZIP, ya link. Live, beta, ya jald — lane tum chuno." },
  },
  {
    n: "05",
    en: { title: "Live save", detail: "It takes a light in the orbit and a page of its own. Edit it any time. Delete the opening samples when you are ready." },
    hi: { title: "Live save", detail: "Woh orbit mein ek roshni leti hai, aur apna page bhi. Kabhi bhi edit karo. Opening samples jab chaho hata do." },
  },
] as const;

export const nameBeats = [
  {
    en: { title: "A presence", detail: "Ankit Hai means Ankit is here. The page should answer when the name is called." },
    hi: { title: "Ek presence", detail: "Ankit Hai ka matlab hai: Ankit yahin hai. Naam pukara jaye to page jawab de." },
  },
  {
    en: { title: "Not a costume", detail: "No invented city, no fake résumé. The line in the brand desk is the line the world sees." },
    hi: { title: "Naqaab nahi", detail: "Na banaaya hua sheher, na jhoothi biography. Brand desk mein jo line likhoge, duniya wahi dekhegi." },
  },
  {
    en: { title: "Work is the proof", detail: "Apps, explanations, and a file or a link. The name stays. The orbit changes as you ship." },
    hi: { title: "Kaam hi saboot hai", detail: "Apps, explanations, aur ek file ya link. Naam rehta hai. Jaise ship karoge, orbit badalti rahegi." },
  },
] as const;
