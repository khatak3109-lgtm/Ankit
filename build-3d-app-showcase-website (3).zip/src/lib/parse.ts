import type { AppInput, AppStatus, FeatureItem } from "@/lib/types";
import { PLATFORMS } from "@/lib/types";

function clean(value: string) {
  return value.replace(/[\u0000-\u001F]/g, "").trim();
}

function clip(value: string, max: number) {
  return clean(value).slice(0, max);
}

export function slugify(input: string) {
  const base = input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 72);
  return base;
}

function asStatus(value: string): AppStatus | null {
  if (value === "live" || value === "beta" || value === "soon") return value;
  return null;
}

function validOptionalUrl(value: string) {
  if (!value) return true;
  return /^https?:\/\/\S+$/i.test(value);
}

function validCover(value: string) {
  if (!value) return true;
  if (value.startsWith("/covers/") || value.startsWith("/brand/")) return !value.includes("..");
  return /^https?:\/\/\S+$/i.test(value);
}

export function parseAppForm(form: FormData): { ok: true; data: AppInput } | { ok: false; error: string } {
  const name = clip(String(form.get("name") || ""), 80);
  if (name.length < 2) return { ok: false, error: "App ka naam likho." };

  const tagline = clip(String(form.get("tagline") || ""), 180);
  if (tagline.length < 4) return { ok: false, error: "Ek chhoti si tagline likho — log yahi pehle padhenge." };

  const description = clip(String(form.get("description") || ""), 500);
  if (description.length < 8) return { ok: false, error: "Short explanation likho. Yeh card par dikhegi." };

  const story = clip(String(form.get("story") || ""), 4000);
  if (story.length < 20) return { ok: false, error: "Kahani thodi lambi likho. Log samajhna chahte hain app kya karti hai." };

  const audience = clip(String(form.get("audience") || ""), 220);
  if (audience.length < 4) return { ok: false, error: "Likho yeh app kiske liye hai." };

  const highlight = clip(String(form.get("highlight") || ""), 220);
  if (highlight.length < 4) return { ok: false, error: "Ek line mein likho jo is app ko alag karti hai." };

  const category = clip(String(form.get("category") || "Other"), 40) || "Other";
  const status = asStatus(String(form.get("status") || "live"));
  if (!status) return { ok: false, error: "Status live, beta, ya soon hona chahiye." };

  const version = clip(String(form.get("version") || "1.0.0"), 24) || "1.0.0";
  const accent = String(form.get("accent") || "#ff8a2a").trim();
  if (!/^#[0-9a-fA-F]{6}$/.test(accent)) return { ok: false, error: "Accent color #rrggbb jaisi honi chahiye." };

  const titles = form.getAll("featureTitle").map((item) => clip(String(item), 80));
  const details = form.getAll("featureDetail").map((item) => clip(String(item), 240));
  const features: FeatureItem[] = titles
    .map((title, index) => ({ title, detail: details[index] || "" }))
    .filter((feature) => feature.title.length > 0)
    .slice(0, 12);
  if (features.length === 0) return { ok: false, error: "Kam se kam ek feature likho, aur usse explain karo." };

  const platforms = form
    .getAll("platforms")
    .map((item) => clip(String(item), 24))
    .filter((item) => item.length > 0 && (PLATFORMS as readonly string[]).includes(item));
  if (platforms.length === 0) return { ok: false, error: "Kam se kam ek platform chuno." };

  const websiteUrl = clip(String(form.get("websiteUrl") || ""), 400);
  if (!validOptionalUrl(websiteUrl)) return { ok: false, error: "Website link http:// ya https:// se shuru ho." };

  const coverUrl = clip(String(form.get("coverUrl") || ""), 400);
  if (!validCover(coverUrl)) return { ok: false, error: "Cover link http se shuru ho, ya opening cover rehne do." };

  const slug = slugify(String(form.get("slug") || ""));

  return {
    ok: true,
    data: {
      name,
      slug,
      tagline,
      description,
      story,
      audience,
      highlight,
      category,
      status,
      version,
      platforms,
      features,
      accent,
      websiteUrl,
      coverUrl,
      featured: form.get("featured") != null,
    },
  };
}

export function parseMessageForm(form: FormData): { ok: true; data: { name: string; email: string; topic: string; message: string } } | { ok: false; error: string } {
  if (String(form.get("company") || "").trim()) {
    return { ok: true, data: { name: "quiet", email: "quiet@example.com", topic: "quiet", message: "quiet" } };
  }
  const name = clip(String(form.get("name") || ""), 80);
  const email = clip(String(form.get("email") || ""), 160);
  const topic = clip(String(form.get("topic") || ""), 40);
  const message = clip(String(form.get("message") || ""), 2000);
  if (name.length < 2) return { ok: false, error: "Apna naam likho." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, error: "Email theek se likho." };
  if (topic.length < 2) return { ok: false, error: "Topic chuno." };
  if (message.length < 8) return { ok: false, error: "Sandesh thoda aur likho." };
  return { ok: true, data: { name, email, topic, message } };
}

export function isQuietMessage(data: { email: string }) {
  return data.email === "quiet@example.com";
}
