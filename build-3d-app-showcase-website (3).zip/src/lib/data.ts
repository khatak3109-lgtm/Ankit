import { cache } from "react";
import { desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { apps, messages, settings } from "@/db/schema";
import { slugify } from "@/lib/parse";
import type { AppInput, AppPublic, AppStatus, FeatureItem, InboxMessage, Profile } from "@/lib/types";
import { DEFAULT_PROFILE } from "@/lib/types";
import { asFile, removeUpload, saveUpload } from "@/lib/uploads";

function ago(days: number) {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
}

function seedApps() {
  const base = {
    iconFile: null,
    coverFile: null,
    bundleFile: null,
    bundleName: null,
    websiteUrl: null,
    sample: true,
    downloads: 0,
    views: 0,
  };
  return [
    {
      ...base,
      slug: "roshni",
      name: "Roshni",
      tagline: "Raat ke kaam ke liye ek naram focus lamp.",
      description: "Ek task, ek pool of light, aur baaki kamra dheere se peeche chala jata hai.",
      story:
        "Roshni ek timer nahi hai jo tumhe daant de. Yeh ek kamra hai jo kaam ke hisaab se roshni kam karta hai. Task chuno, session chuno — 25, 40, ya apna stretch — aur screen ke kinare par sirf woh ek kaam chamke. Ant mein alarm nahi, ek fade hai. Isliye raat ko banane wale log isse lamp ki tarah kholte hain, app ki tarah nahi.",
      audience: "Jo log raat ko banate hain aur screen se kamra haar jaate hain.",
      highlight: "Light task ke saath chalti hai. Timer tumhe sharminda nahi karta.",
      category: "Focus",
      status: "live",
      version: "1.4.0",
      platforms: ["Web", "Desktop"],
      accent: "#ff8a2a",
      coverUrl: "/covers/roshni.jpg",
      featured: true,
      features: [
        { title: "Task pool", detail: "Ek chamakta kaam, baaki sab wait par." },
        { title: "Teen lambai", detail: "25, 40, ya custom dial." },
        { title: "Room tones", detail: "Rain, fan, ya ek shaant gali." },
        { title: "End fade", detail: "Ant mein alarm nahi, dheere se light wapas." },
        { title: "Daily orbit", detail: "Din bhar ke pure hue pools ek gol mein." },
      ],
      createdAt: ago(12),
      updatedAt: ago(2),
    },
    {
      ...base,
      slug: "chhoti-kitaab",
      name: "Chhoti Kitaab",
      tagline: "Ek thumb ki journal. Hindi, English, ya dono.",
      description: "Lambi diary nahi — ek screen, ek page, jo bhasha tumhare dimaag mein hai.",
      story:
        "Chhoti Kitaab un logon ke liye hai jo journal kholte hain aur homework jaisa mehsoos karke band kar dete hain. Page itna chhota hai ki ek thought kaafi hai. Hindi aur English ek hi panne par reh sakte hain. Mahine ke ant mein ek saaf PDF nikal aati hai, bina kisi theme store ke.",
      audience: "Jo log likhna chahte hain, lekin diary ko bojh nahi banana chahte.",
      highlight: "Ek page, ek thumb, jis bhasha mein tum sochte ho.",
      category: "Notes",
      status: "live",
      version: "0.9.2",
      platforms: ["Android", "iOS"],
      accent: "#e6c2a0",
      coverUrl: "/covers/kitaab.jpg",
      featured: false,
      features: [
        { title: "One-screen page", detail: "Scroll ka guilt nahi." },
        { title: "Dono bhashayein", detail: "Hindi aur English saath." },
        { title: "Quiet lock", detail: "Pattern lock, lecture nahi." },
        { title: "Month PDF", detail: "Mahina ek saaf file mein." },
        { title: "Mood ink", detail: "Page ka rang din ke hisaab se." },
      ],
      createdAt: ago(10),
      updatedAt: ago(4),
    },
    {
      ...base,
      slug: "nukkad",
      name: "Nukkad",
      tagline: "Mohalle ke chhote kaam, ek board par.",
      description: "Doodh, chaabi, station tak lift — group chat mein kho jaane se pehle.",
      story:
        "Nukkad ek feed nahi hai. Yeh ek board hai jahan padosi ek zarurat chipkaate hain aur seedha us insaan ko ping karte hain jisse woh pehchaanate hain. Comments ka shor nahi. Kaam ho jaye to loop band. Beta hai, kyunki trust ring abhi mohalle ke hisaab se seekh rahi hai.",
      audience: "Jo log abhi bhi group chat mein madad maangte hain aur message kho dete hain.",
      highlight: "Kaam ka chehra aur lane hai, beech ka shor nahi.",
      category: "Local",
      status: "beta",
      version: "0.6.0",
      platforms: ["Android", "Web"],
      accent: "#ffb020",
      coverUrl: "/covers/nukkad.jpg",
      featured: false,
      features: [
        { title: "Need card", detail: "Doodh, chaabi, seedhi, station tak ride." },
        { title: "Lanes", detail: "Aaj, is hafte, ya jo tum de sakte ho." },
        { title: "Trust ring", detail: "Sirf jinhe tum jaante ho." },
        { title: "Direct ping", detail: "Public comments nahi." },
        { title: "Close the loop", detail: "Kaam ho gaya, card hat gaya." },
      ],
      createdAt: ago(8),
      updatedAt: ago(1),
    },
    {
      ...base,
      slug: "taal",
      name: "Taal",
      tagline: "Jeb mein ek dhyaan se seekhne wala rhythm coach.",
      description: "Teen taal, keherwa, dadra — speed kam ho, pitch bigde nahi.",
      story:
        "Taal students ke liye hai jo ginti kho dete hain aur phir practice chhod dete hain. Beat slip hone par app daantti nahi — woh dikhati hai ki haath kahan aage ya peeche tha. Speed dheemi hoti hai bina chipmunk ke. Streak softly reset hoti hai, taaki ek chhutti poori practice ko mita na de.",
      audience: "Tabla, dholak, ya sirf steady time seekhne wale.",
      highlight: "Beat naram rehti hai jab tum phisal jao, aur jagah dikha deti hai.",
      category: "Music",
      status: "live",
      version: "1.1.0",
      platforms: ["Android", "iOS", "Web"],
      accent: "#e7c15a",
      coverUrl: "/covers/taal.jpg",
      featured: false,
      features: [
        { title: "Taals", detail: "Teen taal, keherwa, dadra, aur khaali canvas." },
        { title: "Slow, same pitch", detail: "Dheema suno, awaaz na badle." },
        { title: "Drift map", detail: "Tap karo, dekho kahan khise." },
        { title: "Lesson loops", detail: "4 beats se poora cycle." },
        { title: "Soft streak", detail: "Ek chhutti sab khatam nahi karti." },
      ],
      createdAt: ago(7),
      updatedAt: ago(3),
    },
    {
      ...base,
      slug: "hisab",
      name: "Hisab",
      tagline: "Chhoti dukaan ke liye gol, shaant hisaab.",
      description: "Rows nahi, rings. Mahina pehle dikhe, math baad mein.",
      story:
        "Hisab un counters ke liye hai jahan spreadsheet ek drama ban jaati hai. Din ek ring hai: aaya, gaya, bacha. Udhaar ek list hai jismein yaad dilana hai, dhamkana nahi. Cash aur UPI alag rang hain. Din band karna ek minute se kam mein hona chahiye, taaki band karte waqt thakaan aur na badhe.",
      audience: "Kirana counters aur freelancers jo spreadsheet theater se thak gaye hain.",
      highlight: "Pehle mahina dikhta hai, phir math.",
      category: "Money",
      status: "live",
      version: "2.0.1",
      platforms: ["Android", "Web"],
      accent: "#2ef2c5",
      coverUrl: "/covers/hisab.jpg",
      featured: false,
      features: [
        { title: "Day ring", detail: "Aaya, gaya, bacha — ek gol." },
        { title: "Udhaar", detail: "Naram reminder, dhamki nahi." },
        { title: "Do rang", detail: "Cash alag, UPI alag." },
        { title: "One-minute close", detail: "Din band, jaldi." },
        { title: "Export", detail: "Asli kitab rakhne wale ke liye file." },
      ],
      createdAt: ago(5),
      updatedAt: ago(1),
    },
    {
      ...base,
      slug: "aasmaan",
      name: "Aasmaan",
      tagline: "Mausam ko number nahi, mood samajhne wali app.",
      description: "Agle 12 ghante, terrace se, jaise koi insaan bata raha ho.",
      story:
        "Aasmaan percentage ka dump nahi hai. Woh agle 12 ghante ko ek terrace ki tarah dikhati hai: kab chhat geeli hogi, kab hawa badlegi, kab kuch carry karne ki zarurat nahi. Abhi soon hai — listing pehle hai, build baad mein orbit mein aayegi. Explanation pehle, taaki log jaanein yeh kis liye bani hai.",
      audience: "Jo log percentage se nahi, aasman dekh kar kapde pehnte hain.",
      highlight: "Agle 12 ghante, insaan ki tarah likhe hue.",
      category: "Weather",
      status: "soon",
      version: "0.1.0",
      platforms: ["Android", "iOS"],
      accent: "#7ec8ff",
      coverUrl: "/covers/aasmaan.jpg",
      featured: false,
      features: [
        { title: "Terrace view", detail: "10 din ka dump nahi, 12 ghante." },
        { title: "Plain lines", detail: "4 baje ke baad chhat geeli hogi." },
        { title: "Carry cues", detail: "Chhata, layer, ya kuch nahi." },
        { title: "City pins", detail: "Jahan tum sach mein jaate ho." },
        { title: "Quiet alerts", detail: "Sirf jab plan badalna chahiye." },
      ],
      createdAt: ago(1),
      updatedAt: ago(1),
    },
  ];
}

function asStatus(value: string): AppStatus {
  if (value === "beta" || value === "soon" || value === "live") return value;
  return "live";
}

function iso(value: Date | string) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function mediaUrl(file: string | null, downloadName?: string | null) {
  if (!file) return null;
  if (!downloadName) return `/api/media/${file}`;
  return `/api/media/${file}?download=1&name=${encodeURIComponent(downloadName)}`;
}

export function present(row: typeof apps.$inferSelect): AppPublic {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    tagline: row.tagline,
    description: row.description,
    story: row.story,
    audience: row.audience,
    highlight: row.highlight,
    category: row.category,
    status: asStatus(row.status),
    version: row.version,
    platforms: row.platforms ?? [],
    features: (row.features ?? []) as FeatureItem[],
    accent: row.accent,
    iconUrl: mediaUrl(row.iconFile),
    coverUrl: row.coverFile ? mediaUrl(row.coverFile) : row.coverUrl,
    bundleUrl: mediaUrl(row.bundleFile, row.bundleName || row.slug),
    bundleName: row.bundleName,
    websiteUrl: row.websiteUrl,
    featured: row.featured,
    sample: row.sample,
    downloads: row.downloads,
    views: row.views,
    createdAt: iso(row.createdAt),
    updatedAt: iso(row.updatedAt),
  };
}

export const ensureSeed = cache(async () => {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(421337)`);
    const existing = await tx.select().from(settings).where(eq(settings.key, "seeded"));
    if (existing.length > 0) return;
    await tx.insert(apps).values(seedApps());
    await tx.insert(settings).values({ key: "seeded", value: "1" });
  });
});

export async function getSetting(key: string) {
  await ensureSeed();
  const [row] = await db.select().from(settings).where(eq(settings.key, key));
  return row?.value ?? null;
}

export async function setSetting(key: string, value: string) {
  await ensureSeed();
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } });
}

export async function getProfile(): Promise<Profile> {
  try {
    const [logo, role, place, bio, focus] = await Promise.all([
      getSetting("logo_url"),
      getSetting("profile_role"),
      getSetting("profile_place"),
      getSetting("profile_bio"),
      getSetting("profile_focus"),
    ]);
    return {
      logoUrl: logo || DEFAULT_PROFILE.logoUrl,
      role: role || DEFAULT_PROFILE.role,
      place: place || "",
      bio: bio || DEFAULT_PROFILE.bio,
      focus: (focus || DEFAULT_PROFILE.focus.join(", "))
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
    };
  } catch (error) {
    console.error(error);
    return DEFAULT_PROFILE;
  }
}

export async function getApps(): Promise<AppPublic[]> {
  try {
    await ensureSeed();
    const rows = await db.select().from(apps).orderBy(desc(apps.featured), desc(apps.createdAt));
    return rows.map(present);
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function getAppBySlug(slug: string) {
  try {
    await ensureSeed();
    const [row] = await db.select().from(apps).where(eq(apps.slug, slug));
    return row ? present(row) : null;
  } catch (error) {
    console.error(error);
    return null;
  }
}

export async function touchView(id: number) {
  try {
    await db.update(apps).set({ views: sql`${apps.views} + 1` }).where(eq(apps.id, id));
  } catch (error) {
    console.error(error);
  }
}

async function uniqueSlug(requested: string, ignoreId?: number) {
  const base = slugify(requested) || `app-${Date.now().toString(36)}`;
  let slug = base;
  for (let n = 2; n < 40; n += 1) {
    const [found] = await db.select({ id: apps.id }).from(apps).where(eq(apps.slug, slug));
    if (!found || found.id === ignoreId) return slug;
    slug = `${base}-${n}`;
  }
  return `${base}-${Date.now().toString(36)}`;
}

function appValues(input: AppInput, slug: string, files: {
  iconFile: string | null;
  coverFile: string | null;
  bundleFile: string | null;
  bundleName: string | null;
}) {
  return {
    slug,
    name: input.name,
    tagline: input.tagline,
    description: input.description,
    story: input.story,
    audience: input.audience,
    highlight: input.highlight,
    category: input.category,
    status: input.status,
    version: input.version,
    platforms: input.platforms,
    features: input.features,
    accent: input.accent,
    coverUrl: input.coverUrl || null,
    websiteUrl: input.websiteUrl || null,
    featured: input.featured,
    sample: false,
    iconFile: files.iconFile,
    coverFile: files.coverFile,
    bundleFile: files.bundleFile,
    bundleName: files.bundleName,
    updatedAt: new Date(),
  };
}

export async function createApp(input: AppInput, form: FormData) {
  await ensureSeed();
  const icon = await saveUpload(asFile(form.get("icon")), "image");
  const cover = await saveUpload(asFile(form.get("cover")), "image");
  const bundle = await saveUpload(asFile(form.get("bundle")), "bundle");
  const slug = await uniqueSlug(input.slug || input.name);
  if (input.featured) {
    await db.update(apps).set({ featured: false });
  }
  const [row] = await db
    .insert(apps)
    .values(
      appValues(input, slug, {
        iconFile: icon?.id ?? null,
        coverFile: cover?.id ?? null,
        bundleFile: bundle?.id ?? null,
        bundleName: bundle?.originalName ?? null,
      }),
    )
    .returning();
  return present(row);
}

export async function updateApp(id: number, input: AppInput, form: FormData) {
  await ensureSeed();
  const [current] = await db.select().from(apps).where(eq(apps.id, id));
  if (!current) return null;
  const icon = await saveUpload(asFile(form.get("icon")), "image");
  const cover = await saveUpload(asFile(form.get("cover")), "image");
  const bundle = await saveUpload(asFile(form.get("bundle")), "bundle");

  let iconFile = current.iconFile;
  let coverFile = current.coverFile;
  let bundleFile = current.bundleFile;
  let bundleName = current.bundleName;

  if (icon || form.get("removeIcon") != null) {
    await removeUpload(iconFile);
    iconFile = icon?.id ?? null;
  }
  if (cover || form.get("removeCover") != null) {
    await removeUpload(coverFile);
    coverFile = cover?.id ?? null;
  }
  if (bundle || form.get("removeBundle") != null) {
    await removeUpload(bundleFile);
    bundleFile = bundle?.id ?? null;
    bundleName = bundle?.originalName ?? null;
  }

  const slug = await uniqueSlug(input.slug || input.name, id);
  if (input.featured) {
    await db.update(apps).set({ featured: false }).where(ne(apps.id, id));
  }
  const [row] = await db
    .update(apps)
    .set(appValues(input, slug, { iconFile, coverFile, bundleFile, bundleName }))
    .where(eq(apps.id, id))
    .returning();
  return present(row);
}

export async function deleteApp(id: number) {
  await ensureSeed();
  const [current] = await db.select().from(apps).where(eq(apps.id, id));
  if (!current) return false;
  await removeUpload(current.iconFile);
  await removeUpload(current.coverFile);
  await removeUpload(current.bundleFile);
  await db.delete(apps).where(eq(apps.id, id));
  return true;
}

export async function clearSamples() {
  await ensureSeed();
  const rows = await db.select().from(apps).where(eq(apps.sample, true));
  for (const row of rows) {
    await removeUpload(row.iconFile);
    await removeUpload(row.coverFile);
    await removeUpload(row.bundleFile);
  }
  await db.delete(apps).where(eq(apps.sample, true));
  return rows.length;
}

export async function restoreSamples() {
  await ensureSeed();
  const existing = await db.select({ slug: apps.slug }).from(apps);
  const slugs = new Set(existing.map((row) => row.slug));
  const missing = seedApps().filter((app) => !slugs.has(app.slug));
  if (missing.length === 0) return 0;
  await db.insert(apps).values(missing);
  return missing.length;
}

export async function getDownloadTarget(id: number) {
  await ensureSeed();
  const [row] = await db.select().from(apps).where(eq(apps.id, id));
  if (!row) return null;
  const target = row.bundleFile
    ? `/api/media/${row.bundleFile}?download=1&name=${encodeURIComponent(row.bundleName || row.slug)}`
    : row.websiteUrl;
  if (!target) return null;
  await db.update(apps).set({ downloads: sql`${apps.downloads} + 1` }).where(eq(apps.id, id));
  return target;
}

export async function listMessages(): Promise<InboxMessage[]> {
  try {
    await ensureSeed();
    const rows = await db.select().from(messages).orderBy(desc(messages.createdAt));
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      email: row.email,
      topic: row.topic,
      message: row.message,
      createdAt: iso(row.createdAt),
    }));
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function createMessage(input: { name: string; email: string; topic: string; message: string }) {
  await ensureSeed();
  const [row] = await db.insert(messages).values(input).returning();
  return row;
}

export async function deleteMessage(id: number) {
  await ensureSeed();
  await db.delete(messages).where(eq(messages.id, id));
}
