import { randomUUID } from "crypto";
import { mkdir, unlink, writeFile } from "fs/promises";
import path from "path";

export const UPLOAD_DIR = path.join(process.cwd(), "data", "uploads");

const IMAGE_EXT = new Set([".png", ".jpg", ".jpeg", ".webp", ".gif"]);
const BUNDLE_EXT = new Set([".zip", ".apk", ".aab", ".ipa", ".pdf", ".dmg"]);

export class UploadError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "UploadError";
  }
}

export function asFile(value: FormDataEntryValue | null) {
  if (!value || typeof value === "string" || value.size === 0) return null;
  return value;
}

export async function saveUpload(file: File | null, kind: "image" | "bundle") {
  if (!file) return null;
  const ext = path.extname(file.name).toLowerCase();
  const allowed = kind === "image" ? IMAGE_EXT : BUNDLE_EXT;
  if (!allowed.has(ext)) {
    throw new UploadError(
      kind === "image"
        ? "Image PNG, JPG, WEBP ya GIF honi chahiye."
        : "File ZIP, APK, AAB, IPA, PDF ya DMG honi chahiye.",
    );
  }
  const max = kind === "image" ? 5 * 1024 * 1024 : 24 * 1024 * 1024;
  if (file.size > max) {
    throw new UploadError(kind === "image" ? "Image 5MB se chhoti rakho." : "File 24MB se chhoti rakho. Badi file ke liye link lagao.");
  }
  await mkdir(UPLOAD_DIR, { recursive: true });
  const id = `${randomUUID()}${ext}`;
  const bytes = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(UPLOAD_DIR, id), bytes);
  return { id, originalName: file.name.replace(/[^\w.\- ()]+/g, "").slice(0, 160) || `file${ext}` };
}

export async function removeUpload(id: string | null | undefined) {
  if (!id || !/^[\w.-]+$/.test(id)) return;
  await unlink(path.join(UPLOAD_DIR, id)).catch(() => undefined);
}

export const MEDIA_TYPES: Record<string, string> = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".pdf": "application/pdf",
  ".zip": "application/zip",
  ".apk": "application/vnd.android.package-archive",
  ".aab": "application/octet-stream",
  ".ipa": "application/octet-stream",
  ".dmg": "application/octet-stream",
};
