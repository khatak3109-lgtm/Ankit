import { cookies } from "next/headers";
import { getSetting } from "@/lib/data";

export const STUDIO_COOKIE = "ankit_studio";
export const DEFAULT_STUDIO_KEY = "ankit-hai";

export async function expectedStudioKey() {
  const stored = await getSetting("studio_key");
  return stored || process.env.STUDIO_KEY || DEFAULT_STUDIO_KEY;
}

export async function isStudioAuthed() {
  const jar = await cookies();
  const value = jar.get(STUDIO_COOKIE)?.value;
  if (!value) return false;
  const key = await expectedStudioKey();
  return value === key;
}

export async function setStudioCookie(key: string, request: Request) {
  const forwarded = request.headers.get("x-forwarded-proto");
  const secure = forwarded ? forwarded.split(",")[0]?.trim() === "https" : new URL(request.url).protocol === "https:";
  const jar = await cookies();
  jar.set(STUDIO_COOKIE, key, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 45,
    secure,
  });
}

export async function clearStudioCookie() {
  const jar = await cookies();
  jar.delete(STUDIO_COOKIE);
}
