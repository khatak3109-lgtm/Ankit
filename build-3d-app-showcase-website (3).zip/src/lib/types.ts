export type Lang = "en" | "hi";

export type FeatureItem = {
  title: string;
  detail: string;
};

export type AppStatus = "live" | "beta" | "soon";

export type AppPublic = {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  story: string;
  audience: string;
  highlight: string;
  category: string;
  status: AppStatus;
  version: string;
  platforms: string[];
  features: FeatureItem[];
  accent: string;
  iconUrl: string | null;
  coverUrl: string | null;
  bundleUrl: string | null;
  bundleName: string | null;
  websiteUrl: string | null;
  featured: boolean;
  sample: boolean;
  downloads: number;
  views: number;
  createdAt: string;
  updatedAt: string;
};

export type AppInput = {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  story: string;
  audience: string;
  highlight: string;
  category: string;
  status: AppStatus;
  version: string;
  platforms: string[];
  features: FeatureItem[];
  accent: string;
  websiteUrl: string;
  coverUrl: string;
  featured: boolean;
};

export type Profile = {
  logoUrl: string;
  role: string;
  place: string;
  bio: string;
  focus: string[];
};

export type InboxMessage = {
  id: number;
  name: string;
  email: string;
  topic: string;
  message: string;
  createdAt: string;
};

export const PLATFORMS = ["Android", "iOS", "Web", "Desktop"] as const;

export const CATEGORIES = [
  "Focus",
  "Notes",
  "Local",
  "Music",
  "Money",
  "Weather",
  "Tools",
  "Games",
  "Learn",
  "Health",
  "Social",
  "Other",
] as const;

export const DEFAULT_PROFILE: Profile = {
  logoUrl: "/brand/mark.png",
  role: "App maker",
  place: "",
  bio: "अंकित है — yeh ek naam nahi, ek presence hai. Yeh studio un apps ke liye hai jo main khud banata hoon: upload, explanation, aur seedha download. Opening collection sirf orbit dikhane ke liye hai. Apni apps rakh do, logo badal do, aur signal ko apna bana lo.",
  focus: ["Original apps", "Clear explanations", "Direct downloads"],
};

export function tx(lang: Lang, en: string, hi: string) {
  return lang === "hi" ? hi : en;
}

export function siteUrl() {
  return process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || "";
}
