import Link from "next/link";

export default function NotFound() {
  return (
    <div className="page gate">
      <div className="glass gate-card">
        <p className="kicker">404</p>
        <h1 className="display">Yeh light orbit mein nahi hai.</h1>
        <p>This page is not in the sky. Wapas catalog par chalo.</p>
        <Link className="btn btn-primary" href="/">
          Ankit Hai
        </Link>
      </div>
    </div>
  );
}
