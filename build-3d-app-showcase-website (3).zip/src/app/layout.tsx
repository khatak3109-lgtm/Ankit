import type { Metadata, Viewport } from "next";
import { Outfit, Syne } from "next/font/google";
import { cookies } from "next/headers";
import type { ReactNode } from "react";
import { Chrome } from "@/components/site/Chrome";
import { getProfile } from "@/lib/data";
import type { Lang } from "@/lib/types";
import "./globals.css";

const syne = Syne({ subsets: ["latin"], variable: "--font-syne", display: "swap" });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit", display: "swap" });

export const dynamic = "force-dynamic";

export const viewport: Viewport = {
  themeColor: "#09080d",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: {
    default: "Ankit Hai — apps in orbit",
    template: "%s · Ankit Hai",
  },
  description:
    "Ankit Hai ek 3D app studio hai. Apne apps upload karo, unki kahani likho, logo lagao, aur unhe orbit mein dikhao.",
  keywords: ["Ankit Hai", "Ankit", "अंकित है", "Ankit apps", "Ankit Hai studio", "Ankit Hai website"],
  authors: [{ name: "Ankit" }],
  applicationName: "Ankit Hai",
  openGraph: {
    title: "Ankit Hai — apps in orbit",
    description: "Ankit ka 3D studio. Original apps, explained, and ready to download.",
    siteName: "Ankit Hai",
    images: [{ url: "/brand/hero.jpg", alt: "Ankit Hai" }],
    locale: "hi_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ankit Hai",
    description: "Ankit ka 3D app studio.",
    images: ["/brand/hero.jpg"],
  },
  robots: { index: true, follow: true },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const profile = await getProfile();
  const jar = await cookies();
  const initialLang: Lang = jar.get("ankit_lang")?.value === "en" ? "en" : "hi";

  return (
    <html lang={initialLang === "hi" ? "hi" : "en"} className={`${syne.variable} ${outfit.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Chrome profile={profile} initialLang={initialLang}>
          {children}
        </Chrome>
      </body>
    </html>
  );
}
