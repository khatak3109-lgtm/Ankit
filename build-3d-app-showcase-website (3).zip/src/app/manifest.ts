import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Ankit Hai",
    short_name: "Ankit Hai",
    description: "Ankit ka 3D app studio — apne apps upload karo, samjhao, aur orbit mein dikhao.",
    start_url: "/",
    display: "standalone",
    background_color: "#09080d",
    theme_color: "#09080d",
    lang: "hi",
    icons: [{ src: "/brand/mark.png", sizes: "640x640", type: "image/png" }],
  };
}
