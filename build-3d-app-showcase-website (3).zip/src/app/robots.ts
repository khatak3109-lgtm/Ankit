import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/types";

export default function robots(): MetadataRoute.Robots {
  const site = siteUrl();
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/studio", "/api"] }],
    sitemap: site ? `${site}/sitemap.xml` : undefined,
  };
}
