import type { Metadata } from "next";
import { StudioDesk } from "@/components/studio/StudioDesk";
import { isStudioAuthed } from "@/lib/auth";
import { getApps, listMessages } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Studio",
  robots: { index: false, follow: false },
};

export default async function StudioPage({ searchParams }: { searchParams: Promise<{ edit?: string }> }) {
  const [{ edit }, authed] = await Promise.all([searchParams, isStudioAuthed()]);
  const apps = authed ? await getApps() : [];
  const messages = authed ? await listMessages() : [];
  return <StudioDesk authed={authed} apps={apps} messages={messages} editSlug={edit} />;
}
