export default function Loading() {
  return (
    <div className="page gate">
      <div className="loader" aria-hidden />
      <p>Signal lock ho raha hai…</p>
    </div>
  );
}
