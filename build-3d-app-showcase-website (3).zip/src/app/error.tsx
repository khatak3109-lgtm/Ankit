"use client";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="page gate">
      <div className="glass gate-card">
        <h1 className="display">Signal toot gaya.</h1>
        <p>The page stumbled. Phir se try karo.</p>
        <button className="btn btn-primary" type="button" onClick={() => reset()}>
          Phir se
        </button>
      </div>
    </div>
  );
}
