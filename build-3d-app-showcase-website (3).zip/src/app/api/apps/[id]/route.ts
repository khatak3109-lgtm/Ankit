import { isStudioAuthed } from "@/lib/auth";
import { deleteApp, updateApp } from "@/lib/data";
import { parseAppForm } from "@/lib/parse";
import { UploadError } from "@/lib/uploads";

export const dynamic = "force-dynamic";

function numericId(value: string) {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

async function locked() {
  if (!(await isStudioAuthed())) {
    return Response.json({ error: "Studio locked. Key daalo." }, { status: 401 });
  }
  return null;
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const denied = await locked();
    if (denied) return denied;
    const id = numericId((await context.params).id);
    if (!id) return Response.json({ error: "App nahi mili." }, { status: 404 });
    const form = await request.formData();
    const parsed = parseAppForm(form);
    if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });
    const app = await updateApp(id, parsed.data, form);
    if (!app) return Response.json({ error: "App nahi mili." }, { status: 404 });
    return Response.json({ app });
  } catch (error) {
    console.error(error);
    const message = error instanceof UploadError ? error.message : "App update nahi hui.";
    return Response.json({ error: message }, { status: error instanceof UploadError ? 400 : 500 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const denied = await locked();
    if (denied) return denied;
    const id = numericId((await context.params).id);
    if (!id) return Response.json({ error: "App nahi mili." }, { status: 404 });
    const ok = await deleteApp(id);
    if (!ok) return Response.json({ error: "App nahi mili." }, { status: 404 });
    return Response.json({ ok: true });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "App delete nahi hui." }, { status: 500 });
  }
}
