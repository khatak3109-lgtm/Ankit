import { getDownloadTarget } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id <= 0) return new Response("Not found", { status: 404 });
  try {
    const target = await getDownloadTarget(id);
    if (!target) return new Response("Is app par abhi file ya link nahi hai.", { status: 404 });
    const dest = target.startsWith("http") ? target : new URL(target, request.url).toString();
    return Response.redirect(dest, 302);
  } catch (error) {
    console.error(error);
    return new Response("Download nahi khula.", { status: 500 });
  }
}
