import { isStudioAuthed } from "@/lib/auth";
import { createApp } from "@/lib/data";
import { parseAppForm } from "@/lib/parse";
import { UploadError } from "@/lib/uploads";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    if (!(await isStudioAuthed())) {
      return Response.json({ error: "Studio locked. Key daalo." }, { status: 401 });
    }
    const form = await request.formData();
    const parsed = parseAppForm(form);
    if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });
    const app = await createApp(parsed.data, form);
    return Response.json({ app });
  } catch (error) {
    console.error(error);
    const message = error instanceof UploadError ? error.message : "App save nahi hui.";
    return Response.json({ error: message }, { status: error instanceof UploadError ? 400 : 500 });
  }
}
