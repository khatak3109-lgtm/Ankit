import { isStudioAuthed } from "@/lib/auth";
import { deleteMessage } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isStudioAuthed())) return Response.json({ error: "Studio locked." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id <= 0) return Response.json({ error: "Signal nahi mila." }, { status: 404 });
  await deleteMessage(id);
  return Response.json({ ok: true });
}
