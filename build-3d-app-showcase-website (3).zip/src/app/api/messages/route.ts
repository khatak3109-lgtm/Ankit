import { isStudioAuthed } from "@/lib/auth";
import { createMessage, listMessages } from "@/lib/data";
import { isQuietMessage, parseMessageForm } from "@/lib/parse";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isStudioAuthed())) return Response.json({ error: "Studio locked." }, { status: 401 });
  const messages = await listMessages();
  return Response.json({ messages });
}

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const parsed = parseMessageForm(form);
    if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });
    if (!isQuietMessage(parsed.data)) await createMessage(parsed.data);
    return Response.json({ ok: true });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Signal nahi gaya." }, { status: 500 });
  }
}
