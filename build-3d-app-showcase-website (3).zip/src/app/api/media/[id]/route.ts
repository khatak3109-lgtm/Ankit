import { createReadStream } from "fs";
import { stat } from "fs/promises";
import path from "path";
import { Readable } from "stream";
import { MEDIA_TYPES, UPLOAD_DIR } from "@/lib/uploads";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!/^[a-zA-Z0-9.-]+$/.test(id)) return new Response("Not found", { status: 404 });
  const filePath = path.join(UPLOAD_DIR, id);
  try {
    const info = await stat(filePath);
    if (!info.isFile()) return new Response("Not found", { status: 404 });
    const ext = path.extname(id).toLowerCase();
    const url = new URL(request.url);
    const download = url.searchParams.get("download") === "1";
    const name = (url.searchParams.get("name") || id).replace(/[^\w.\- ()]+/g, "") || id;
    const headers = new Headers({
      "Content-Type": MEDIA_TYPES[ext] || "application/octet-stream",
      "Content-Length": String(info.size),
      "Cache-Control": "public, max-age=31536000, immutable",
    });
    if (download) headers.set("Content-Disposition", `attachment; filename="${name}"`);
    const stream = Readable.toWeb(createReadStream(filePath)) as ReadableStream;
    return new Response(stream, { headers });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
