import { clearStudioCookie } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  await clearStudioCookie();
  return Response.json({ ok: true });
}
