import { clearStudioCookie, expectedStudioKey, isStudioAuthed, setStudioCookie } from "@/lib/auth";
import { getSetting, setSetting } from "@/lib/data";
import { asFile, removeUpload, saveUpload, UploadError } from "@/lib/uploads";

export const dynamic = "force-dynamic";

function clip(value: string, max: number) {
  return value.replace(/[\u0000-\u001F]/g, "").trim().slice(0, max);
}

export async function POST(request: Request) {
  try {
    if (!(await isStudioAuthed())) return Response.json({ error: "Studio locked." }, { status: 401 });
    const form = await request.formData();
    const role = clip(String(form.get("role") || ""), 80);
    const place = clip(String(form.get("place") || ""), 80);
    const bio = clip(String(form.get("bio") || ""), 800);
    const focus = clip(String(form.get("focus") || ""), 180);
    const nextKey = clip(String(form.get("nextKey") || ""), 80);
    if (role.length < 2) return Response.json({ error: "Role likho — jaise App maker." }, { status: 400 });
    if (bio.length < 12) return Response.json({ error: "Bio thodi lambi likho. Yahi public page par dikhegi." }, { status: 400 });
    if (nextKey && (nextKey.length < 6 || /\s/.test(nextKey))) {
      return Response.json({ error: "Nayi key kam se kam 6 akshar, bina space." }, { status: 400 });
    }

    await setSetting("profile_role", role);
    await setSetting("profile_place", place);
    await setSetting("profile_bio", bio);
    await setSetting("profile_focus", focus);

    const logo = await saveUpload(asFile(form.get("logo")), "image");
    if (logo) {
      const previous = await getSetting("logo_url");
      if (previous?.startsWith("/api/media/")) {
        await removeUpload(previous.split("/").pop());
      }
      await setSetting("logo_url", `/api/media/${logo.id}`);
    }

    if (nextKey) {
      await setSetting("studio_key", nextKey);
      await clearStudioCookie();
      await setStudioCookie(nextKey, request);
    }

    const key = await expectedStudioKey();
    return Response.json({ ok: true, keyChanged: Boolean(nextKey), keyHint: nextKey ? "changed" : key === "ankit-hai" ? "default" : "custom" });
  } catch (error) {
    console.error(error);
    const message = error instanceof UploadError ? error.message : "Brand save nahi hua.";
    return Response.json({ error: message }, { status: error instanceof UploadError ? 400 : 500 });
  }
}
