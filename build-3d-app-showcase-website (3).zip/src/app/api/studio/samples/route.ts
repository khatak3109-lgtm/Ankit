import { isStudioAuthed } from "@/lib/auth";
import { clearSamples, restoreSamples } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function DELETE() {
  if (!(await isStudioAuthed())) return Response.json({ error: "Studio locked." }, { status: 401 });
  const count = await clearSamples();
  return Response.json({ ok: true, count });
}

export async function POST() {
  if (!(await isStudioAuthed())) return Response.json({ error: "Studio locked." }, { status: 401 });
  const count = await restoreSamples();
  return Response.json({ ok: true, count });
}
