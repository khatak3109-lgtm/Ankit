import { expectedStudioKey, setStudioCookie } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { key?: string };
    const key = String(body.key || "");
    const expected = await expectedStudioKey();
    if (!key || key !== expected) {
      return Response.json({ error: "Key match nahi hui." }, { status: 401 });
    }
    await setStudioCookie(key, request);
    return Response.json({ ok: true });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Studio abhi nahi khula. Thodi der baad try karo." }, { status: 500 });
  }
}
