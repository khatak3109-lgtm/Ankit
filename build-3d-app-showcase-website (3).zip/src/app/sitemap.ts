import type { MetadataRoute } from "next";
import { getApps } from "@/lib/data";
import { siteUrl } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const site = siteUrl() || "http://localhost:3000";
  const apps = await getApps();
  return [
    { url: `${site}/`, changeFrequency: "daily", priority: 1 },
    { url: `${site}/apps`, changeFrequency: "daily", priority: 0.8 },
    ...apps.map((app) => ({
      url: `${site}/apps/${app.slug}`,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })),
  ];
}
