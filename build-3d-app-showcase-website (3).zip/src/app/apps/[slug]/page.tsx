import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AppDetailView } from "@/components/apps/AppDetailView";
import { getAppBySlug, getApps, touchView } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const app = await getAppBySlug(slug);
  if (!app) return { title: "App" };
  return {
    title: app.name,
    description: app.tagline,
    openGraph: {
      title: `${app.name} · Ankit Hai`,
      description: app.description,
      images: app.coverUrl ? [app.coverUrl] : ["/brand/hero.jpg"],
    },
  };
}

export default async function AppPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [app, apps] = await Promise.all([getAppBySlug(slug), getApps()]);
  if (!app) notFound();
  await touchView(app.id);
  const seen = { ...app, views: app.views + 1 };
  const related = [
    ...apps.filter((item) => item.id !== app.id && item.category === app.category),
    ...apps.filter((item) => item.id !== app.id && item.category !== app.category),
  ].slice(0, 3);

  return <AppDetailView app={seen} related={related} />;
}
