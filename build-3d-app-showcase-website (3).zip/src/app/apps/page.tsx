import type { Metadata } from "next";
import { AppsExplorer } from "@/components/apps/AppsExplorer";
import { getApps } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Apps",
  description: "Ankit Hai ki saari apps — explanations, platforms, aur download.",
};

export default async function AppsPage() {
  const apps = await getApps();
  return <AppsExplorer apps={apps} />;
}
