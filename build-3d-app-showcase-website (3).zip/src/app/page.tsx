import { HomeExperience } from "@/components/home/HomeExperience";
import { getApps, getProfile } from "@/lib/data";
import { siteUrl } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function Page() {
  const [apps, profile] = await Promise.all([getApps(), getProfile()]);
  const site = siteUrl();
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        name: "Ankit Hai",
        alternateName: ["अंकित है", "Ankit"],
        description: "Ankit Hai is a 3D studio for original apps — upload, explain, and keep them in orbit.",
        inLanguage: ["hi", "en"],
        ...(site ? { url: site } : {}),
      },
      {
        "@type": "Person",
        name: "Ankit",
        alternateName: "Ankit Hai",
        description: profile.bio,
        jobTitle: profile.role,
        ...(site ? { url: site } : {}),
      },
      {
        "@type": "ItemList",
        name: "Ankit Hai apps",
        itemListElement: apps.map((app, index) => ({
          "@type": "ListItem",
          position: index + 1,
          item: {
            "@type": "SoftwareApplication",
            name: app.name,
            applicationCategory: app.category,
            operatingSystem: app.platforms.join(", "),
            description: app.description,
            softwareVersion: app.version,
            ...(site ? { url: `${site}/apps/${app.slug}` } : {}),
          },
        })),
      },
    ],
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <HomeExperience apps={apps} />
    </>
  );
}
