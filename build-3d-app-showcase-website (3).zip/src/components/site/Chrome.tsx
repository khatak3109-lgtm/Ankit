"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Lang, Profile } from "@/lib/types";
import { tx } from "@/lib/types";

type SiteValue = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  profile: Profile;
};

const SiteContext = createContext<SiteValue | null>(null);

export function useLang() {
  const value = useContext(SiteContext);
  if (!value) throw new Error("Language missing");
  return value;
}

const links = [
  { href: "/#orbit", en: "Orbit", hi: "Orbit" },
  { href: "/apps", en: "Apps", hi: "Apps" },
  { href: "/#path", en: "How", hi: "Kaise" },
  { href: "/#craft", en: "Craft", hi: "Kaam" },
  { href: "/#signal", en: "Signal", hi: "Sandesh" },
];

function Glow() {
  useEffect(() => {
    const node = document.getElementById("glow");
    if (!node) return;
    const move = (event: PointerEvent) => {
      node.style.transform = `translate(${event.clientX - 180}px, ${event.clientY - 180}px)`;
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);
  return null;
}

export function Chrome({
  children,
  profile,
  initialLang,
}: {
  children: ReactNode;
  profile: Profile;
  initialLang: Lang;
}) {
  const [lang, setLangState] = useState<Lang>(initialLang);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  function setLang(next: Lang) {
    setLangState(next);
    document.cookie = `ankit_lang=${next}; path=/; max-age=31536000; samesite=lax`;
  }

  useEffect(() => {
    document.documentElement.lang = lang === "hi" ? "hi" : "en";
  }, [lang]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <SiteContext.Provider value={{ lang, setLang, profile }}>
      <div className="pointer-glow" id="glow" />
      <Glow />
      <div className="spine" aria-hidden>
        <span>Ankit Hai · अंकित है</span>
      </div>
      <a className="skip" href="#content">
        Skip
      </a>
      <header className="nav">
        <div className="nav-inner">
          <Link href="/" className="brand-lock" aria-label="Ankit Hai">
            <img src={profile.logoUrl} alt="" className="logo-img" />
            <span>
              <strong>Ankit Hai</strong>
              <em>{profile.role}</em>
            </span>
          </Link>
          <nav className="nav-links" aria-label="Primary">
            {links.map((link) => (
              <Link key={link.href} href={link.href} className={pathname === link.href ? "on" : undefined}>
                {tx(lang, link.en, link.hi)}
              </Link>
            ))}
          </nav>
          <div className="nav-actions">
            <div className="lang-toggle" role="group" aria-label="Language">
              <button type="button" aria-pressed={lang === "hi"} onClick={() => setLang("hi")}>
                HI
              </button>
              <button type="button" aria-pressed={lang === "en"} onClick={() => setLang("en")}>
                EN
              </button>
            </div>
            <Link href="/studio" className="btn btn-primary btn-tiny">
              {tx(lang, "Upload", "Upload")}
            </Link>
            <button type="button" className="menu-btn" aria-expanded={open} aria-label="Menu" onClick={() => setOpen((value) => !value)}>
              <i />
              <i />
            </button>
          </div>
        </div>
      </header>
      {open ? (
        <div className="mobile-panel">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              {tx(lang, link.en, link.hi)}
            </Link>
          ))}
          <Link href="/studio">{tx(lang, "Studio desk", "Studio desk")}</Link>
        </div>
      ) : null}
      <div className="wrap" id="content">
        {children}
      </div>
      <footer className="footer">
        <div>
          <img src={profile.logoUrl} alt="" className="logo-img" />
          <strong>Ankit Hai</strong>
          <p>{tx(lang, "The name stays. The orbit changes.", "Naam rehta hai. Orbit badalti rehti hai.")}</p>
        </div>
        <div className="footer-links">
          <Link href="/apps">Apps</Link>
          <Link href="/studio">Studio</Link>
          <Link href="/#signal">{tx(lang, "Signal", "Sandesh")}</Link>
        </div>
        <p className="fine">
          {tx(lang, "Opening photographs via Pexels. Logo slot is yours to replace.", "Opening photographs Pexels se. Logo ki jagah tumhari hai.")}
        </p>
      </footer>
    </SiteContext.Provider>
  );
}
