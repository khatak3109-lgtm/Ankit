"use client";

import { useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Float, Stars } from "@react-three/drei";
import { ACESFilmicToneMapping, MathUtils, Vector3, type Group, type Mesh } from "three";
import type { AppPublic } from "@/lib/types";

type WorldProps = {
  apps: AppPublic[];
  activeId: number | null;
  compact?: boolean;
  onSelect: (id: number) => void;
  onHover: (app: AppPublic | null) => void;
};

function Rig() {
  const { camera, pointer } = useThree();
  useFrame(() => {
    camera.position.x = MathUtils.lerp(camera.position.x, pointer.x * 0.62, 0.045);
    camera.position.y = MathUtils.lerp(camera.position.y, 0.16 + pointer.y * 0.32, 0.045);
    camera.lookAt(0, 0, 0);
  });
  return null;
}

function Core() {
  const gem = useRef<Mesh>(null);
  useFrame(({ clock }) => {
    if (!gem.current) return;
    gem.current.rotation.y = clock.elapsedTime * 0.18;
    gem.current.rotation.x = Math.sin(clock.elapsedTime * 0.23) * 0.22;
  });

  return (
    <Float speed={1.25} rotationIntensity={0.18} floatIntensity={0.42}>
      <mesh ref={gem}>
        <icosahedronGeometry args={[1.02, 1]} />
        <meshStandardMaterial color="#2a160d" emissive="#ff7a1a" emissiveIntensity={0.85} metalness={0.62} roughness={0.24} flatShading />
      </mesh>
      <mesh rotation={[Math.PI / 2.15, 0.22, 0.08]}>
        <torusGeometry args={[1.7, 0.015, 16, 180]} />
        <meshBasicMaterial color="#2ef2c5" />
      </mesh>
      <mesh rotation={[0.62, 0.84, 0.2]}>
        <torusGeometry args={[2.05, 0.008, 12, 160]} />
        <meshBasicMaterial color="#ffb067" transparent opacity={0.72} />
      </mesh>
      <mesh>
        <octahedronGeometry args={[1.5, 0]} />
        <meshBasicMaterial color="#f6f1e8" wireframe transparent opacity={0.16} />
      </mesh>
    </Float>
  );
}

function Node({
  app,
  position,
  active,
  onSelect,
  onHover,
}: {
  app: AppPublic;
  position: [number, number, number];
  active: boolean;
  onSelect: (id: number) => void;
  onHover: (app: AppPublic | null) => void;
}) {
  const ref = useRef<Mesh>(null);
  const scale = useRef(new Vector3(1, 1, 1));
  const [hot, setHot] = useState(false);

  useFrame(() => {
    const next = hot || active ? 1.5 : 1;
    scale.current.set(next, next, next);
    ref.current?.scale.lerp(scale.current, 0.14);
  });

  return (
    <group position={position}>
      <mesh
        ref={ref}
        onPointerOver={(event) => {
          event.stopPropagation();
          setHot(true);
          onHover(app);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHot(false);
          onHover(null);
          document.body.style.cursor = "";
        }}
        onClick={(event) => {
          event.stopPropagation();
          onSelect(app.id);
        }}
      >
        <sphereGeometry args={[0.16, 28, 28]} />
        <meshStandardMaterial color={app.accent} emissive={app.accent} emissiveIntensity={hot || active ? 2.1 : 0.9} roughness={0.28} metalness={0.2} />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.3, 18, 18]} />
        <meshBasicMaterial color={app.accent} transparent opacity={hot || active ? 0.28 : 0.1} />
      </mesh>
    </group>
  );
}

function Orbit({ apps, activeId, onSelect, onHover }: Omit<WorldProps, "compact">) {
  const group = useRef<Group>(null);
  const items = useMemo(() => apps.slice(0, 9), [apps]);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.1;
  });

  return (
    <group ref={group}>
      <mesh rotation={[Math.PI / 2.35, 0.1, 0]}>
        <torusGeometry args={[2.72, 0.004, 8, 200]} />
        <meshBasicMaterial color="#f6f1e8" transparent opacity={0.2} />
      </mesh>
      {items.map((app, index) => {
        const angle = (index / Math.max(items.length, 1)) * Math.PI * 2;
        const position: [number, number, number] = [
          Math.cos(angle) * 2.72,
          Math.sin(angle * 2) * 0.46,
          Math.sin(angle) * 2.72,
        ];
        return (
          <Node
            key={app.id}
            app={app}
            position={position}
            active={activeId === app.id}
            onSelect={onSelect}
            onHover={onHover}
          />
        );
      })}
    </group>
  );
}

export function World({ apps, activeId, compact = false, onSelect, onHover }: WorldProps) {
  return (
    <Canvas
      camera={{ position: [0, 0.18, compact ? 7.5 : 6.05], fov: compact ? 46 : 40 }}
      dpr={[1, 1.5]}
      gl={{ antialias: true, alpha: true }}
      style={{ width: "100%", height: "100%", touchAction: "pan-y" }}
      onPointerMissed={() => onHover(null)}
      onCreated={({ gl }) => {
        gl.setClearColor(0x000000, 0);
        gl.toneMapping = ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.2;
      }}
    >
      <ambientLight intensity={1.05} />
      <hemisphereLight color="#ffe0c2" groundColor="#14121c" intensity={0.7} />
      <pointLight position={[3.4, 2.2, 3.2]} intensity={30} color="#ff8a2a" distance={14} />
      <pointLight position={[-3.4, -1.2, 2.4]} intensity={18} color="#2ef2c5" distance={12} />
      <Stars radius={48} depth={24} count={compact ? 420 : 760} factor={2.2} fade speed={0.35} />
      <Rig />
      <Core />
      <Orbit apps={apps} activeId={activeId} onSelect={onSelect} onHover={onHover} />
    </Canvas>
  );
}
