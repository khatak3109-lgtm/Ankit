"use client";

import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import { Component, useEffect, useMemo, useState, type ReactNode } from "react";
import { AppCard } from "@/components/apps/AppCard";
import { useLang } from "@/components/site/Chrome";
import type { AppPublic } from "@/lib/types";
import { tx } from "@/lib/types";

const World = dynamic(() => import("@/components/scene/World").then((mod) => mod.World), { ssr: false });

class SkyBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

export function AppsExplorer({ apps }: { apps: AppPublic[] }) {
  const { lang } = useLang();
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [platform, setPlatform] = useState("All");
  const [sort, setSort] = useState("new");
  const [shown, setShown] = useState(9);
  const [activeId, setActiveId] = useState<number | null>(apps.find((app) => app.featured)?.id ?? null);
  const [webgl, setWebgl] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    setWebgl(!reduce && Boolean(gl));
  }, []);

  const categories = ["All", ...Array.from(new Set(apps.map((app) => app.category)))];
  const platforms = ["All", ...Array.from(new Set(apps.flatMap((app) => app.platforms)))];

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const next = apps.filter((app) => {
      const hay = [app.name, app.tagline, app.category, app.description, app.story, ...app.features.map((feature) => feature.title)]
        .join(" ")
        .toLowerCase();
      if (needle && !hay.includes(needle)) return false;
      if (category !== "All" && app.category !== category) return false;
      if (platform !== "All" && !app.platforms.includes(platform)) return false;
      return true;
    });
    next.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "pulse") return b.downloads - a.downloads || b.views - a.views;
      return b.createdAt.localeCompare(a.createdAt);
    });
    return next;
  }, [apps, category, platform, query, sort]);

  return (
    <div className="page">
      <header className="page-head">
        <p className="kicker">{tx(lang, "Full catalog", "Poora catalog")}</p>
        <h1 className="display">{tx(lang, "Every light, named.", "Har roshni, naam ke saath.")}</h1>
        <p>
          {tx(
            lang,
            "Search the sky by name, category, or platform. Tap a light to open its explanation.",
            "Naam, category, ya platform se dhoondo. Roshni chhuo, explanation khulegi.",
          )}
        </p>
      </header>
      <div className="apps-sky">
        {webgl ? (
          <SkyBoundary fallback={<img className="sky-fallback" src="/brand/hero.jpg" alt="" />}>
            <World
              compact
              apps={apps}
              activeId={activeId}
              onHover={() => undefined}
              onSelect={(id) => {
                setActiveId(id);
                const app = apps.find((item) => item.id === id);
                if (app) router.push(`/apps/${app.slug}`);
              }}
            />
          </SkyBoundary>
        ) : (
          <img className="sky-fallback" src="/brand/hero.jpg" alt="" />
        )}
      </div>
      <div className="filter-bar">
        <label className="field grow">
          <span>{tx(lang, "Search", "Dhoondo")}</span>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={tx(lang, "Name, feature, story", "Naam, feature, kahani")} />
        </label>
        <label className="field">
          <span>{tx(lang, "Sort", "Kram")}</span>
          <select value={sort} onChange={(event) => setSort(event.target.value)}>
            <option value="new">{tx(lang, "Newest", "Nayi")}</option>
            <option value="pulse">{tx(lang, "Most pulses", "Zyada pulse")}</option>
            <option value="name">{tx(lang, "Name", "Naam")}</option>
          </select>
        </label>
      </div>
      <div className="chip-row">
        {categories.map((item) => (
          <button key={item} type="button" className={category === item ? "chip on" : "chip"} onClick={() => setCategory(item)}>
            {item === "All" ? tx(lang, "All lanes", "Sab") : item}
          </button>
        ))}
      </div>
      <div className="chip-row soft">
        {platforms.map((item) => (
          <button key={item} type="button" className={platform === item ? "chip on" : "chip"} onClick={() => setPlatform(item)}>
            {item === "All" ? tx(lang, "All platforms", "Sab platforms") : item}
          </button>
        ))}
      </div>
      <p className="result-count">
        {filtered.length} {tx(lang, "showing", "dikh rahi hain")}
      </p>
      {filtered.length === 0 ? (
        <div className="empty">
          <p>{tx(lang, "Nothing in this lane.", "Is lane mein kuch nahi.")}</p>
        </div>
      ) : (
        <div className="deck">
          {filtered.slice(0, shown).map((app) => (
            <AppCard key={app.id} app={app} active={app.id === activeId} />
          ))}
        </div>
      )}
      {shown < filtered.length ? (
        <button type="button" className="btn btn-ghost more" onClick={() => setShown((value) => value + 9)}>
          {tx(lang, "Show more", "Aur dikhao")}
        </button>
      ) : null}
    </div>
  );
}
