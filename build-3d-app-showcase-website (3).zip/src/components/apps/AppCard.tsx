"use client";

import Link from "next/link";
import { useRef } from "react";
import { useLang } from "@/components/site/Chrome";
import type { AppPublic, Lang } from "@/lib/types";
import { tx } from "@/lib/types";

export function statusLabel(status: AppPublic["status"], lang: Lang) {
  if (status === "soon") return tx(lang, "Soon", "Jald");
  if (status === "beta") return "Beta";
  return "Live";
}

export function AppCard({ app, active = false }: { app: AppPublic; active?: boolean }) {
  const { lang } = useLang();
  const ref = useRef<HTMLAnchorElement>(null);

  function move(event: React.MouseEvent<HTMLAnchorElement>) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    el.style.transform = `rotateY(${x * 8}deg) rotateX(${-y * 8}deg) translateY(-6px)`;
  }

  return (
    <Link
      id={`app-${app.id}`}
      href={`/apps/${app.slug}`}
      ref={ref}
      onMouseMove={move}
      onMouseLeave={() => {
        if (ref.current) ref.current.style.transform = "";
      }}
      className={`app-card${app.featured ? " featured" : ""}${active ? " active" : ""}`}
      style={{ "--accent": app.accent } as React.CSSProperties}
    >
      {app.coverUrl ? <img className="cover" src={app.coverUrl} alt="" /> : <span className="monogram">{app.name.slice(0, 1)}</span>}
      <span className="shade" />
      <span className="card-body">
        <span className="card-top">
          <span className={`pill ${app.status}`}>{statusLabel(app.status, lang)}</span>
          {app.sample ? <span className="pill ghost">{tx(lang, "Opening", "Shuruaat")}</span> : null}
          <span className="mono">{app.category}</span>
        </span>
        <strong className="card-name">{app.name}</strong>
        <span className="card-line">{app.tagline}</span>
        <span className="card-meta">
          <span>{app.platforms.join(" · ")}</span>
          <span>v{app.version}</span>
        </span>
      </span>
    </Link>
  );
}
