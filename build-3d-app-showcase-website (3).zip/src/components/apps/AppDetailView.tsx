"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { AppCard, statusLabel } from "@/components/apps/AppCard";
import { useLang } from "@/components/site/Chrome";
import type { AppPublic } from "@/lib/types";
import { tx } from "@/lib/types";

function Device({ app }: { app: AppPublic }) {
  const ref = useRef<HTMLDivElement>(null);

  function move(event: React.MouseEvent<HTMLDivElement>) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    el.style.transform = `rotateY(${x * 14}deg) rotateX(${-y * 10}deg)`;
  }

  return (
    <div className="device-wrap">
      <div
        className="device"
        ref={ref}
        onMouseMove={move}
        onMouseLeave={() => {
          if (ref.current) ref.current.style.transform = "";
        }}
      >
        <div
          className="device-screen"
          style={{
            backgroundImage: app.coverUrl ? `linear-gradient(180deg, rgba(9,8,13,0.15), rgba(9,8,13,0.78)), url(${app.coverUrl})` : undefined,
            backgroundColor: app.accent,
          }}
        >
          <div className="device-ui">
            <div className="device-icon" style={{ background: app.accent }}>
              {app.iconUrl ? <img src={app.iconUrl} alt="" /> : app.name.slice(0, 1)}
            </div>
            <strong>{app.name}</strong>
            <p>{app.tagline}</p>
            <ul>
              {app.features.slice(0, 4).map((feature) => (
                <li key={feature.title}>{feature.title}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function CopyLink() {
  const { lang } = useLang();
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="btn btn-ghost"
      onClick={async () => {
        await navigator.clipboard.writeText(window.location.href);
        setDone(true);
        window.setTimeout(() => setDone(false), 1400);
      }}
    >
      {done ? tx(lang, "Copied", "Copy ho gaya") : tx(lang, "Copy link", "Link copy")}
    </button>
  );
}

export function AppDetailView({ app, related }: { app: AppPublic; related: AppPublic[] }) {
  const { lang } = useLang();
  const paragraphs = app.story.split(/\n+/).filter(Boolean);

  return (
    <article className="detail">
      <header className="detail-hero" style={{ "--accent": app.accent } as React.CSSProperties}>
        {app.coverUrl ? <img className="detail-cover" src={app.coverUrl} alt="" /> : null}
        <div className="detail-shade" />
        <div className="detail-inner">
          <div>
            <Link className="back" href="/apps">
              ← {tx(lang, "All apps", "Saari apps")}
            </Link>
            <div className="card-top">
              <span className={`pill ${app.status}`}>{statusLabel(app.status, lang)}</span>
              {app.sample ? <span className="pill ghost">{tx(lang, "Opening", "Shuruaat")}</span> : null}
              <span className="mono">{app.category}</span>
            </div>
            <h1 className="display">{app.name}</h1>
            <p className="tagline">{app.tagline}</p>
            <p className="lede">{app.description}</p>
            <div className="hero-actions">
              {app.bundleUrl ? (
                <a className="btn btn-primary" href={`/api/apps/${app.id}/download`}>
                  {tx(lang, "Download build", "Build lo")}
                </a>
              ) : null}
              {app.websiteUrl ? (
                <a className="btn btn-ghost" href={app.websiteUrl} target="_blank" rel="noreferrer">
                  {tx(lang, "Open link", "Link kholo")}
                </a>
              ) : null}
              <CopyLink />
              <Link className="btn btn-ghost" href={`/studio?edit=${app.slug}`}>
                {tx(lang, "Edit in studio", "Studio mein badlo")}
              </Link>
            </div>
            {!app.bundleUrl && !app.websiteUrl ? (
              <p className="quiet">{tx(lang, "No file attached yet. The explanation is the first release.", "Abhi file nahi judi. Pehli release explanation hai.")}</p>
            ) : null}
          </div>
          <Device app={app} />
        </div>
      </header>
      <section className="detail-body">
        <div className="explain-grid">
          <div>
            <p className="kicker">{tx(lang, "Explain", "Explain")}</p>
            <h2 className="display small">{tx(lang, "What it actually does", "Yeh sach mein kya karti hai")}</h2>
            {paragraphs.map((paragraph) => (
              <p key={paragraph.slice(0, 24)}>{paragraph}</p>
            ))}
          </div>
          <aside className="side-facts">
            <div className="callout">
              <span>{tx(lang, "Who it is for", "Kiske liye")}</span>
              <p>{app.audience}</p>
            </div>
            <div className="callout">
              <span>{tx(lang, "The difference", "Alag kya hai")}</span>
              <p>{app.highlight}</p>
            </div>
            <dl className="facts">
              <div>
                <dt>Version</dt>
                <dd>{app.version}</dd>
              </div>
              <div>
                <dt>{tx(lang, "Platforms", "Platforms")}</dt>
                <dd>{app.platforms.join(", ")}</dd>
              </div>
              <div>
                <dt>{tx(lang, "Looks", "Nazar")}</dt>
                <dd>{app.views}</dd>
              </div>
              <div>
                <dt>{tx(lang, "Pulses", "Pulse")}</dt>
                <dd>{app.downloads}</dd>
              </div>
            </dl>
          </aside>
        </div>
        <h2 className="display small">{tx(lang, "Features", "Features")}</h2>
        <div className="feature-grid">
          {app.features.map((feature, index) => (
            <article key={`${feature.title}-${index}`}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <h3>{feature.title}</h3>
              <p>{feature.detail || feature.title}</p>
            </article>
          ))}
        </div>
      </section>
      {related.length > 0 ? (
        <section className="section tight">
          <h2 className="display small">{tx(lang, "Nearby in the orbit", "Orbit mein paas")}</h2>
          <div className="deck">
            {related.map((item) => (
              <AppCard key={item.id} app={item} />
            ))}
          </div>
        </section>
      ) : null}
    </article>
  );
}
