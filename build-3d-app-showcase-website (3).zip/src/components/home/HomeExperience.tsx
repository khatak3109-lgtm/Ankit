"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { Component, useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { AppCard } from "@/components/apps/AppCard";
import { useLang } from "@/components/site/Chrome";
import { craftFeatures, nameBeats, steps } from "@/lib/content";
import type { AppPublic } from "@/lib/types";
import { tx } from "@/lib/types";

const World = dynamic(() => import("@/components/scene/World").then((mod) => mod.World), { ssr: false });

function Poster() {
  return (
    <div className="poster">
      <img src="/brand/hero.jpg" alt="" />
      <img src="/brand/mark.png" alt="" className="poster-mark" />
    </div>
  );
}

class StageBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

function Marquee({ names }: { names: string[] }) {
  const words = names.length ? names : ["Ankit Hai", "Orbit", "Upload", "Explain"];
  return (
    <div className="marquee" aria-hidden>
      <div className="marquee-track">
        {[0, 1].map((copy) => (
          <div className="marquee-group" key={copy}>
            {words.map((word) => (
              <span key={`${copy}-${word}`}>
                {word} <i>✶</i>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function SignalForm() {
  const { lang } = useLang();
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = useState("");

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("sending");
    setError("");
    const res = await fetch("/api/messages", { method: "POST", body: new FormData(event.currentTarget) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setState("idle");
      setError(data.error || tx(lang, "Signal did not leave.", "Signal nahi gaya."));
      return;
    }
    setState("sent");
    event.currentTarget.reset();
  }

  return (
    <form className="signal-form" onSubmit={onSubmit}>
      <label className="hp">
        Company
        <input name="company" tabIndex={-1} autoComplete="off" />
      </label>
      <label className="field">
        <span>{tx(lang, "Name", "Naam")}</span>
        <input name="name" required minLength={2} maxLength={80} placeholder={tx(lang, "Your name", "Tumhara naam")} />
      </label>
      <label className="field">
        <span>Email</span>
        <input name="email" type="email" required maxLength={160} placeholder="you@email.com" />
      </label>
      <label className="field">
        <span>{tx(lang, "Topic", "Topic")}</span>
        <select name="topic" defaultValue="Namaste">
          <option value="Namaste">Namaste</option>
          <option value="Collab">{tx(lang, "Collab", "Saath ka kaam")}</option>
          <option value="Feedback">Feedback</option>
          <option value="Bug">{tx(lang, "Something broke", "Kuch toota")}</option>
        </select>
      </label>
      <label className="field span-2">
        <span>{tx(lang, "Message", "Sandesh")}</span>
        <textarea name="message" required minLength={8} maxLength={2000} rows={5} placeholder={tx(lang, "Say it plain.", "Seedha likho.")} />
      </label>
      {error ? <p className="form-error span-2">{error}</p> : null}
      {state === "sent" ? <p className="form-ok span-2">{tx(lang, "Signal received. It is waiting in the studio.", "Signal mil gaya. Studio mein wait kar raha hai.")}</p> : null}
      <button className="btn btn-primary" type="submit" disabled={state === "sending"}>
        {state === "sending" ? tx(lang, "Sending", "Ja raha hai") : tx(lang, "Send signal", "Signal bhejo")}
      </button>
    </form>
  );
}

export function HomeExperience({ apps }: { apps: AppPublic[] }) {
  const { lang, profile } = useLang();
  const [activeId, setActiveId] = useState<number | null>(apps.find((app) => app.featured)?.id ?? apps[0]?.id ?? null);
  const [hover, setHover] = useState<AppPublic | null>(null);
  const [webgl, setWebgl] = useState(false);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    setWebgl(!reduce && Boolean(gl));
    return () => {
      document.body.style.cursor = "";
    };
  }, []);

  const orbitApps = useMemo(() => [...apps].sort((a, b) => Number(b.featured) - Number(a.featured)).slice(0, 9), [apps]);
  const active = apps.find((app) => app.id === activeId) ?? null;
  const categories = ["All", ...Array.from(new Set(apps.map((app) => app.category)))];
  const shown = apps.filter((app) => filter === "All" || app.category === filter);
  const live = apps.filter((app) => app.status === "live").length;
  const pulses = apps.reduce((sum, app) => sum + app.downloads, 0);
  const looks = apps.reduce((sum, app) => sum + app.views, 0);

  return (
    <>
      <section className="hero">
        <div className="orbit-stage">
          {webgl ? (
            <StageBoundary fallback={<Poster />}>
              <World apps={orbitApps} activeId={activeId} onSelect={setActiveId} onHover={setHover} />
            </StageBoundary>
          ) : (
            <Poster />
          )}
          <div className="stage-caption">
            <span>{hover ? hover.name : tx(lang, "Touch a light", "Roshni ko chhuo")}</span>
            <span>
              {orbitApps.length} {tx(lang, "in orbit", "orbit mein")}
            </span>
          </div>
        </div>
        <div className="hero-copy">
          <p className="kicker">
            <i className="pulse" />
            {tx(lang, "Personal app studio", "Niji app studio")}
          </p>
          <h1 className="display hero-title">
            <span>Ankit</span>
            <span className="hai">Hai.</span>
          </h1>
          <p className="hindi-lock">अंकित है — yahin, in apps ke saath.</p>
          <p className="lede">
            {tx(
              lang,
              "A 3D launchpad for the apps I build. Upload the build, write the explanation, and let the work take a light in the sky.",
              "Yeh mera 3D studio hai. Jo app main banata hoon, usse yahin upload karta hoon, uski kahani likhta hoon, aur woh aasman mein ek roshni ban jaati hai.",
            )}
          </p>
          <div className="hero-actions">
            <a className="btn btn-primary" href="#orbit">
              {tx(lang, "Enter the orbit", "Orbit mein aao")}
            </a>
            <Link className="btn btn-ghost" href="/studio">
              {tx(lang, "Upload an app", "App upload karo")}
            </Link>
          </div>
          <div className="stat-row">
            <div>
              <strong>{apps.length}</strong>
              <span>{tx(lang, "Apps", "Apps")}</span>
            </div>
            <div>
              <strong>{live}</strong>
              <span>Live</span>
            </div>
            <div>
              <strong>{looks}</strong>
              <span>{tx(lang, "Looks", "Nazar")}</span>
            </div>
            <div>
              <strong>{pulses}</strong>
              <span>{tx(lang, "Pulses", "Pulse")}</span>
            </div>
          </div>
          {active ? (
            <article className="glass orbit-card">
              <div>
                <span className="mono" style={{ color: active.accent }}>
                  {active.category} · {active.status}
                </span>
                <h2>{active.name}</h2>
                <p>{active.tagline}</p>
              </div>
              <Link href={`/apps/${active.slug}`}>{tx(lang, "Open explain", "Explain kholo")}</Link>
            </article>
          ) : (
            <article className="glass orbit-card">
              <div>
                <span className="mono">Quiet sky</span>
                <h2>{tx(lang, "The first app becomes the sun.", "Pehli app sooraj banegi.")}</h2>
                <p>{tx(lang, "Upload one from the studio.", "Studio se ek upload karo.")}</p>
              </div>
              <Link href="/studio">{tx(lang, "Open studio", "Studio kholo")}</Link>
            </article>
          )}
        </div>
      </section>
      <Marquee names={apps.map((app) => app.name)} />
      <section id="orbit" className="section">
        <div className="section-head">
          <p className="ghost-index">01</p>
          <div>
            <p className="kicker">{tx(lang, "The catalog", "Catalog")}</p>
            <h2 className="display">{tx(lang, "Apps already in the sky", "Jo apps aasman mein hain")}</h2>
            <p>
              {tx(
                lang,
                "The opening collection shows the shape of the studio. Replace it with the apps you actually ship.",
                "Opening collection studio ka shape dikhati hai. Iski jagah woh apps rakh do jo tum sach mein ship karte ho.",
              )}
            </p>
          </div>
        </div>
        <div className="chip-row">
          {categories.map((category) => (
            <button key={category} type="button" className={filter === category ? "chip on" : "chip"} onClick={() => setFilter(category)}>
              {category === "All" ? tx(lang, "All", "Sab") : category}
            </button>
          ))}
        </div>
        {shown.length === 0 ? (
          <div className="empty">
            <p>{tx(lang, "The orbit is quiet.", "Orbit shaant hai.")}</p>
            <Link className="btn btn-primary" href="/studio">
              {tx(lang, "Upload the first app", "Pehli app chadhhao")}
            </Link>
          </div>
        ) : (
          <div className="deck">
            {shown.map((app) => (
              <AppCard key={app.id} app={app} active={app.id === activeId} />
            ))}
          </div>
        )}
      </section>
      <section id="path" className="section">
        <div className="section-head">
          <p className="ghost-index">02</p>
          <div>
            <p className="kicker">{tx(lang, "The desk", "Desk")}</p>
            <h2 className="display">{tx(lang, "How your app gets in", "App kaise andar aati hai")}</h2>
          </div>
        </div>
        <ol className="steps">
          {steps.map((step) => (
            <li key={step.n}>
              <span>{step.n}</span>
              <h3>{tx(lang, step.en.title, step.hi.title)}</h3>
              <p>{tx(lang, step.en.detail, step.hi.detail)}</p>
            </li>
          ))}
        </ol>
        <p className="key-note">
          {tx(lang, "Creator key", "Creator key")} <code>ankit-hai</code>
          <span>{tx(lang, "Change it inside the studio after you enter.", "Andar jaake badal dena.")}</span>
        </p>
      </section>
      <section id="craft" className="section">
        <div className="section-head">
          <p className="ghost-index">03</p>
          <div>
            <p className="kicker">{tx(lang, "What it holds", "Iske andar")}</p>
            <h2 className="display">{tx(lang, "Features, not filler", "Features, bharna nahi")}</h2>
            <p>
              {tx(
                lang,
                "These are working parts of the studio — the things that happen when you upload, explain, and publish.",
                "Yeh studio ke kaam karte hisson hain — jo hota hai jab tum upload, explain, aur publish karte ho.",
              )}
            </p>
          </div>
        </div>
        <div className="bento">
          {craftFeatures.map((feature) => (
            <article key={feature.key} className={feature.wide ? "craft-card wide" : "craft-card"}>
              <h3>{tx(lang, feature.en.title, feature.hi.title)}</h3>
              <p>{tx(lang, feature.en.detail, feature.hi.detail)}</p>
              {feature.wide ? (
                <div className="mini-orbit" aria-hidden>
                  <i />
                  <i />
                  <i />
                </div>
              ) : null}
            </article>
          ))}
        </div>
      </section>
      <section id="name" className="section name-section">
        <div className="about-grid">
          <div className="mark-frame">
            <img src={profile.logoUrl} alt="Ankit Hai mark" />
          </div>
          <div>
            <p className="kicker">{tx(lang, "The name", "Naam")}</p>
            <h2 className="display">{tx(lang, "Ankit Hai is the answer.", "Ankit Hai hi jawab hai.")}</h2>
            <p className="bio">{profile.bio}</p>
            <p className="place-line">
              {profile.role}
              {profile.place ? ` · ${profile.place}` : ""}
            </p>
            <ul className="focus-list">
              {profile.focus.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="name-grid">
          {nameBeats.map((beat) => (
            <article key={beat.en.title}>
              <h3>{tx(lang, beat.en.title, beat.hi.title)}</h3>
              <p>{tx(lang, beat.en.detail, beat.hi.detail)}</p>
            </article>
          ))}
        </div>
      </section>
      <section id="signal" className="section">
        <div className="signal-grid">
          <div>
            <p className="kicker">04 · Signal</p>
            <h2 className="display">{tx(lang, "Write to the desk.", "Desk ko likho.")}</h2>
            <p>
              {tx(
                lang,
                "Collab, feedback, or a plain hello. It lands in the studio inbox, not in a void.",
                "Saath ka kaam, feedback, ya seedha namaste. Yeh studio inbox mein aata hai, kahin gayab nahi hota.",
              )}
            </p>
          </div>
          <SignalForm />
        </div>
      </section>
    </>
  );
}
