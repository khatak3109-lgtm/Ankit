"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useLang } from "@/components/site/Chrome";
import type { AppPublic, AppStatus, FeatureItem, InboxMessage, Profile } from "@/lib/types";
import { CATEGORIES, PLATFORMS, tx } from "@/lib/types";

type Tab = "publish" | "signals" | "brand";

async function readError(res: Response) {
  const data = await res.json().catch(() => null);
  return data?.error || "Kuch gadbad ho gayi.";
}

function Gate() {
  const { lang } = useLang();
  const router = useRouter();
  const [key, setKey] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    const res = await fetch("/api/studio/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key }),
    });
    setPending(false);
    if (!res.ok) {
      setError(await readError(res));
      return;
    }
    router.refresh();
  }

  return (
    <div className="page gate">
      <div className="glass gate-card">
        <p className="on-air">
          <i /> Studio
        </p>
        <h1 className="display">{tx(lang, "The desk is locked.", "Desk band hai.")}</h1>
        <p>
          {tx(
            lang,
            "This is where apps, the logo, and incoming signals live. The opening key is below — change it after you enter.",
            "Yahin apps, logo, aur aane wale signals rehte hain. Shuruaati key neeche hai — andar jaake badal dena.",
          )}
        </p>
        <form onSubmit={onSubmit} className="stack">
          <label className="field">
            <span>{tx(lang, "Creator key", "Creator key")}</span>
            <input value={key} onChange={(event) => setKey(event.target.value)} type="password" autoComplete="current-password" required />
          </label>
          <p className="key-note">
            <code>ankit-hai</code>
          </p>
          {error ? <p className="form-error">{error}</p> : null}
          <button className="btn btn-primary" type="submit" disabled={pending}>
            {pending ? "..." : tx(lang, "Open the desk", "Desk kholo")}
          </button>
        </form>
      </div>
    </div>
  );
}

function Editor({ app }: { app: AppPublic | null }) {
  const { lang } = useLang();
  const router = useRouter();
  const [name, setName] = useState(app?.name ?? "");
  const [tagline, setTagline] = useState(app?.tagline ?? "");
  const [description, setDescription] = useState(app?.description ?? "");
  const [accent, setAccent] = useState(app?.accent ?? "#ff8a2a");
  const [status, setStatus] = useState<AppStatus>(app?.status ?? "live");
  const [features, setFeatures] = useState<FeatureItem[]>(app?.features.length ? app.features : [{ title: "", detail: "" }]);
  const [platforms, setPlatforms] = useState<string[]>(app?.platforms.length ? app.platforms : ["Android"]);
  const [coverPreview, setCoverPreview] = useState(app?.coverUrl ?? "");
  const [error, setError] = useState("");
  const [banner, setBanner] = useState("");
  const [pending, setPending] = useState(false);

  function togglePlatform(platform: string) {
    setPlatforms((current) => (current.includes(platform) ? current.filter((item) => item !== platform) : [...current, platform]));
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    setBanner("");
    const form = new FormData(event.currentTarget);
    form.delete("platforms");
    platforms.forEach((platform) => form.append("platforms", platform));
    const res = await fetch(app ? `/api/apps/${app.id}` : "/api/apps", { method: app ? "PATCH" : "POST", body: form });
    setPending(false);
    if (!res.ok) {
      setError(await readError(res));
      return;
    }
    setBanner(tx(lang, "Saved. The orbit can see it.", "Save ho gayi. Orbit isse dekh sakti hai."));
    router.refresh();
  }

  async function remove() {
    if (!app) return;
    if (!window.confirm(tx(lang, "Remove this app from the orbit?", "Is app ko orbit se hata du?"))) return;
    const res = await fetch(`/api/apps/${app.id}`, { method: "DELETE" });
    if (!res.ok) {
      setError(await readError(res));
      return;
    }
    router.refresh();
  }

  return (
    <form className="editor" onSubmit={onSubmit}>
      <div className="editor-head">
        <div>
          <p className="kicker">{app ? tx(lang, "Editing", "Badal rahe ho") : tx(lang, "New light", "Nayi roshni")}</p>
          <h2>{name || tx(lang, "Untitled app", "Bina naam app")}</h2>
        </div>
        <div className="preview-pip" style={{ "--accent": accent, backgroundImage: coverPreview ? `url(${coverPreview})` : undefined } as React.CSSProperties}>
          <strong>{name.slice(0, 1) || "A"}</strong>
        </div>
      </div>
      <div className="form-grid">
        <label className="field">
          <span>{tx(lang, "Name", "Naam")}</span>
          <input name="name" value={name} onChange={(event) => setName(event.target.value)} required maxLength={80} placeholder="Roshni" />
        </label>
        <label className="field">
          <span>Slug</span>
          <input name="slug" defaultValue={app?.slug ?? ""} maxLength={80} placeholder="roshni" />
        </label>
        <label className="field span-2">
          <span>Tagline</span>
          <input name="tagline" value={tagline} onChange={(event) => setTagline(event.target.value)} required maxLength={180} placeholder={tx(lang, "One line people remember", "Ek line jo yaad rahe")} />
        </label>
        <label className="field">
          <span>Category</span>
          <input name="category" list="categories" defaultValue={app?.category ?? "Tools"} required maxLength={40} />
          <datalist id="categories">
            {CATEGORIES.map((item) => (
              <option key={item} value={item} />
            ))}
          </datalist>
        </label>
        <label className="field">
          <span>Status</span>
          <select name="status" value={status} onChange={(event) => setStatus(event.target.value as AppStatus)}>
            <option value="live">Live</option>
            <option value="beta">Beta</option>
            <option value="soon">{tx(lang, "Soon", "Jald")}</option>
          </select>
        </label>
        <label className="field">
          <span>Version</span>
          <input name="version" defaultValue={app?.version ?? "1.0.0"} maxLength={24} />
        </label>
        <label className="field">
          <span>Accent</span>
          <input name="accent" type="color" value={accent} onChange={(event) => setAccent(event.target.value)} />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "Short explanation", "Chhoti explanation")}</span>
          <textarea name="description" value={description} onChange={(event) => setDescription(event.target.value)} required maxLength={500} rows={3} />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "Story — what it does, and why", "Kahani — kya karti hai, aur kyun")}</span>
          <textarea name="story" defaultValue={app?.story ?? ""} required minLength={20} maxLength={4000} rows={6} />
        </label>
        <label className="field">
          <span>{tx(lang, "Who it is for", "Kiske liye")}</span>
          <input name="audience" defaultValue={app?.audience ?? ""} required maxLength={220} />
        </label>
        <label className="field">
          <span>{tx(lang, "The one difference", "Ek alag baat")}</span>
          <input name="highlight" defaultValue={app?.highlight ?? ""} required maxLength={220} />
        </label>
      </div>
      <fieldset className="block">
        <legend>{tx(lang, "Platforms", "Platforms")}</legend>
        <div className="check-row">
          {PLATFORMS.map((platform) => (
            <label key={platform} className={platforms.includes(platform) ? "check on" : "check"}>
              <input type="checkbox" checked={platforms.includes(platform)} onChange={() => togglePlatform(platform)} />
              {platform}
            </label>
          ))}
        </div>
      </fieldset>
      <fieldset className="block">
        <legend>{tx(lang, "Features — title and a plain explanation", "Features — naam aur seedhi explanation")}</legend>
        {features.map((feature, index) => (
          <div className="feature-row" key={index}>
            <input
              name="featureTitle"
              value={feature.title}
              placeholder={tx(lang, "Feature", "Feature")}
              onChange={(event) => setFeatures((current) => current.map((item, i) => (i === index ? { ...item, title: event.target.value } : item)))}
            />
            <input
              name="featureDetail"
              value={feature.detail}
              placeholder={tx(lang, "What it means", "Iska matlab")}
              onChange={(event) => setFeatures((current) => current.map((item, i) => (i === index ? { ...item, detail: event.target.value } : item)))}
            />
            <button
              type="button"
              className="icon-btn"
              onClick={() => setFeatures((current) => current.filter((_, i) => i !== index))}
              aria-label="Remove feature"
            >
              ×
            </button>
          </div>
        ))}
        <button type="button" className="btn btn-ghost btn-tiny" onClick={() => setFeatures((current) => [...current, { title: "", detail: "" }])}>
          {tx(lang, "Add feature", "Feature jodo")}
        </button>
      </fieldset>
      <div className="form-grid">
        <label className="field">
          <span>{tx(lang, "Website or store link", "Website ya store link")}</span>
          <input name="websiteUrl" defaultValue={app?.websiteUrl ?? ""} placeholder="https://" />
        </label>
        <label className="field">
          <span>{tx(lang, "Cover link, optional", "Cover link, optional")}</span>
          <input name="coverUrl" defaultValue={app?.coverUrl && !app.coverUrl.startsWith("/api/") ? app.coverUrl : ""} placeholder="https:// or leave blank" />
        </label>
        <label className="field">
          <span>{tx(lang, "Icon image", "Icon image")}</span>
          <input name="icon" type="file" accept="image/png,image/jpeg,image/webp,image/gif" />
        </label>
        <label className="field">
          <span>{tx(lang, "Cover image", "Cover image")}</span>
          <input
            name="cover"
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) setCoverPreview(URL.createObjectURL(file));
            }}
          />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "Build file — APK, ZIP, IPA, PDF, DMG, up to 24MB", "Build file — APK, ZIP, IPA, PDF, DMG, 24MB tak")}</span>
          <input name="bundle" type="file" accept=".apk,.aab,.zip,.ipa,.pdf,.dmg,application/pdf,application/zip" />
          {app?.bundleName ? <em className="file-note">{tx(lang, "Current file", "Abhi ki file")}: {app.bundleName}</em> : null}
        </label>
      </div>
      <div className="check-row">
        <label className="check">
          <input type="checkbox" name="featured" defaultChecked={app?.featured ?? false} />
          {tx(lang, "Pin this to the front of the orbit", "Ise orbit ke aage pin karo")}
        </label>
        {app?.iconUrl ? (
          <label className="check">
            <input type="checkbox" name="removeIcon" />
            {tx(lang, "Remove icon", "Icon hatao")}
          </label>
        ) : null}
        {app?.coverUrl?.startsWith("/api/") ? (
          <label className="check">
            <input type="checkbox" name="removeCover" />
            {tx(lang, "Remove cover file", "Cover file hatao")}
          </label>
        ) : null}
        {app?.bundleUrl ? (
          <label className="check">
            <input type="checkbox" name="removeBundle" />
            {tx(lang, "Remove build", "Build hatao")}
          </label>
        ) : null}
      </div>
      {error ? <p className="form-error">{error}</p> : null}
      {banner ? <p className="form-ok">{banner}</p> : null}
      <div className="save-bar">
        <button className="btn btn-primary" type="submit" disabled={pending}>
          {pending ? tx(lang, "Saving", "Save ho raha hai") : app ? tx(lang, "Update app", "App update karo") : tx(lang, "Publish to orbit", "Orbit mein chadhhao")}
        </button>
        {app ? (
          <button className="btn btn-ghost" type="button" onClick={remove}>
            {tx(lang, "Delete", "Hatao")}
          </button>
        ) : null}
        {app ? (
          <Link className="btn btn-ghost" href={`/apps/${app.slug}`}>
            {tx(lang, "View", "Dekho")}
          </Link>
        ) : null}
      </div>
    </form>
  );
}

function BrandForm({ profile }: { profile: Profile }) {
  const { lang } = useLang();
  const router = useRouter();
  const [error, setError] = useState("");
  const [banner, setBanner] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    setBanner("");
    const res = await fetch("/api/studio/brand", { method: "POST", body: new FormData(event.currentTarget) });
    setPending(false);
    if (!res.ok) {
      setError(await readError(res));
      return;
    }
    setBanner(tx(lang, "Brand saved.", "Brand save ho gaya."));
    router.refresh();
  }

  return (
    <form className="editor" onSubmit={onSubmit}>
      <div className="brand-row">
        <img src={profile.logoUrl} alt="" className="mark-xl" />
        <div>
          <p className="kicker">{tx(lang, "Your mark", "Tumhara mark")}</p>
          <h2>{tx(lang, "Replace the logo when you have it.", "Jab logo ho, yahin laga dena.")}</h2>
          <p>{tx(lang, "PNG, JPG, WEBP, or GIF. It shows in the nav, the about block, and the footer.", "PNG, JPG, WEBP, ya GIF. Yeh nav, about, aur footer mein dikhega.")}</p>
        </div>
      </div>
      <div className="form-grid">
        <label className="field span-2">
          <span>{tx(lang, "Logo file", "Logo file")}</span>
          <input name="logo" type="file" accept="image/png,image/jpeg,image/webp,image/gif" />
        </label>
        <label className="field">
          <span>Role</span>
          <input name="role" defaultValue={profile.role} required maxLength={80} />
        </label>
        <label className="field">
          <span>{tx(lang, "Place, optional", "Jagah, optional")}</span>
          <input name="place" defaultValue={profile.place} maxLength={80} placeholder={tx(lang, "City, if you want it public", "Sheher, agar public rakhna ho")} />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "Public line", "Public line")}</span>
          <textarea name="bio" defaultValue={profile.bio} required minLength={12} maxLength={800} rows={5} />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "Focus words, comma separated", "Focus words, comma se")}</span>
          <input name="focus" defaultValue={profile.focus.join(", ")} maxLength={180} />
        </label>
        <label className="field span-2">
          <span>{tx(lang, "New studio key, leave blank to keep", "Nayi studio key, khali chhodo to purani rahegi")}</span>
          <input name="nextKey" type="password" autoComplete="new-password" minLength={6} placeholder={tx(lang, "At least 6 characters", "Kam se kam 6 akshar")} />
        </label>
      </div>
      <div className="note-block">
        <h3>{tx(lang, "To be found on Google", "Google par aane ke liye")}</h3>
        <ol>
          <li>{tx(lang, "Point a domain at this site.", "Apna domain is site par lagao.")}</li>
          <li>NEXT_PUBLIC_SITE_URL set karo, jaise https://ankithai.com</li>
          <li>{tx(lang, "In Search Console, submit /sitemap.xml.", "Search Console mein /sitemap.xml submit karo.")}</li>
        </ol>
        <p>{tx(lang, "The page already speaks the name: Ankit Hai, in the title, the description, and structured data.", "Page pehle se naam bolta hai: Ankit Hai — title, description, aur structured data mein.")}</p>
      </div>
      {error ? <p className="form-error">{error}</p> : null}
      {banner ? <p className="form-ok">{banner}</p> : null}
      <div className="save-bar">
        <button className="btn btn-primary" disabled={pending} type="submit">
          {pending ? "..." : tx(lang, "Save brand", "Brand save karo")}
        </button>
      </div>
    </form>
  );
}

export function StudioDesk({
  authed,
  apps,
  messages,
  editSlug,
}: {
  authed: boolean;
  apps: AppPublic[];
  messages: InboxMessage[];
  editSlug?: string;
}) {
  const { lang, profile } = useLang();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("publish");
  const [selectedId, setSelectedId] = useState<number | "new">(apps.find((app) => app.slug === editSlug)?.id ?? "new");
  const [note, setNote] = useState("");

  useEffect(() => {
    if (typeof selectedId === "number" && !apps.some((app) => app.id === selectedId)) setSelectedId("new");
  }, [apps, selectedId]);

  if (!authed) return <Gate />;

  const editing = typeof selectedId === "number" ? apps.find((app) => app.id === selectedId) ?? null : null;
  const samples = apps.filter((app) => app.sample).length;

  async function clearSamples() {
    if (!window.confirm(tx(lang, "Remove the opening collection?", "Opening collection hata du?"))) return;
    const res = await fetch("/api/studio/samples", { method: "DELETE" });
    if (!res.ok) {
      setNote(await readError(res));
      return;
    }
    setSelectedId("new");
    setNote(tx(lang, "Opening collection cleared.", "Opening collection hat gayi."));
    router.refresh();
  }

  async function restore() {
    const res = await fetch("/api/studio/samples", { method: "POST" });
    if (!res.ok) {
      setNote(await readError(res));
      return;
    }
    setNote(tx(lang, "Opening collection restored where names were free.", "Jahan naam khali the, opening collection wapas aa gayi."));
    router.refresh();
  }

  async function logout() {
    await fetch("/api/studio/logout", { method: "POST" });
    router.refresh();
  }

  async function dismiss(id: number) {
    await fetch(`/api/messages/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <div className="page studio">
      <header className="studio-top">
        <div>
          <p className="on-air">
            <i /> {tx(lang, "On air", "On air")}
          </p>
          <h1 className="display">{tx(lang, "Studio desk", "Studio desk")}</h1>
          <p>{tx(lang, "Upload your own apps, swap the logo, read signals.", "Apni apps chadhhao, logo badlo, signals padho.")}</p>
        </div>
        <button type="button" className="btn btn-ghost" onClick={logout}>
          {tx(lang, "Lock desk", "Desk band karo")}
        </button>
      </header>
      <div className="tab-row">
        <button type="button" className={tab === "publish" ? "chip on" : "chip"} onClick={() => setTab("publish")}>
          {tx(lang, "Publish", "Publish")}
        </button>
        <button type="button" className={tab === "signals" ? "chip on" : "chip"} onClick={() => setTab("signals")}>
          {tx(lang, "Signals", "Signals")} {messages.length ? `(${messages.length})` : ""}
        </button>
        <button type="button" className={tab === "brand" ? "chip on" : "chip"} onClick={() => setTab("brand")}>
          {tx(lang, "Brand", "Brand")}
        </button>
      </div>
      {note ? <p className="form-ok">{note}</p> : null}
      {tab === "publish" ? (
        <div className="studio-grid">
          <aside className="app-list">
            <button type="button" className={selectedId === "new" ? "list-item on" : "list-item"} onClick={() => setSelectedId("new")}>
              <strong>{tx(lang, "New app", "Nayi app")}</strong>
              <span>{tx(lang, "Add a light", "Ek roshni jodo")}</span>
            </button>
            {apps.map((app) => (
              <button key={app.id} type="button" className={selectedId === app.id ? "list-item on" : "list-item"} onClick={() => setSelectedId(app.id)}>
                <strong>{app.name}</strong>
                <span>
                  {app.status} · {app.sample ? tx(lang, "opening", "shuruaat") : "yours"}
                </span>
              </button>
            ))}
            <div className="list-actions">
              {samples > 0 ? (
                <button type="button" className="btn btn-ghost btn-tiny" onClick={clearSamples}>
                  {tx(lang, "Clear opening apps", "Opening apps hatao")}
                </button>
              ) : (
                <button type="button" className="btn btn-ghost btn-tiny" onClick={restore}>
                  {tx(lang, "Restore opening apps", "Opening apps wapas")}
                </button>
              )}
            </div>
          </aside>
          <Editor key={editing ? editing.id : "new"} app={editing} />
        </div>
      ) : null}
      {tab === "signals" ? (
        <div className="inbox">
          {messages.length === 0 ? <p className="empty">{tx(lang, "No signals yet.", "Abhi koi signal nahi.")}</p> : null}
          {messages.map((message) => (
            <article key={message.id} className="signal-card">
              <header>
                <strong>{message.name}</strong>
                <span className="pill ghost">{message.topic}</span>
              </header>
              <a href={`mailto:${message.email}`}>{message.email}</a>
              <p>{message.message}</p>
              <footer>
                <time dateTime={message.createdAt}>{new Date(message.createdAt).toLocaleString(lang === "hi" ? "hi-IN" : "en-IN")}</time>
                <button type="button" className="btn btn-ghost btn-tiny" onClick={() => dismiss(message.id)}>
                  {tx(lang, "Clear", "Hatao")}
                </button>
              </footer>
            </article>
          ))}
        </div>
      ) : null}
      {tab === "brand" ? <BrandForm key={`${profile.logoUrl}-${profile.bio}`} profile={profile} /> : null}
    </div>
  );
}
